/**
 * Netflix NFToken Studio - Front-end Application Controller
 * High-performance client with Random Cookie Pool, TV Activation, and Admin Panel.
 */

// Bilingual Dictionary
const I18N = {
  ar: {
    headerSubtitle: "مولد التوكنات وتفعيل التلفزيون",
    serverOnline: "الخادم متصل",
    availableCookies: "الكوكيز المتوفرة:",
    deviceQuotaLabel: "المتبقي لجهازك اليوم:",
    quotaHintPrefix: "الرصيد اليومي لهذا الجهاز:",
    adminPanel: "لوحة الأدمن",
    heroBadge: "نظام التوليد العشوائي الذكي",
    heroTitle: "XNetflix — مولد التوكنات وتفعيل التلفاز",
    heroDesc: "",
    tabGenerator: "تفعيل نتفلكس",
    tabTv: "تفعيل تلفزيون نتفلكس",
    tabHistory: "السجل والتوكنات",
    tabGuide: "طريقة الاستخدام",
    poolSpotlightHeading: "مستودع الكوكيز الجاهزة:",
    cookiesWord: "حساب متوفر",
    poolSpotlightSub: "",
    btnGenerateRandom: "Generate Netflix",
    btnHelperText: "* نقرة واحدة تكفي! سيقوم النظام بالمصادقة الآمنة وإعطائك رابط الدخول ورمز QR فوراً.",
    toggleCustomCookie: "لديك كوكيز خاص بك؟ (إدخال يدوي مخصص)",
    loadFromInput: "تحميل من input.txt",
    clearInput: "مسح",
    btnGenerateCustomAction: "توليد من الكوكيز المدخل أعلاه",
    waitingTitle: "بانتظار إنشاء التوكن",
    waitingDesc: "اضغط على زر التوليد في الجهة المقابلة ليتم سحب كوكيز عشوائي وإنشاء رابط المصادقة المباشر ورمز الاستجابة السريعة (QR Code).",
    f1: "تسجيل دخول فوري بدون باسورد",
    f2: "رمز QR للمسح من الهاتف",
    f3: "تفعيل مباشر لأجهزة التلفاز",
    tokenGeneratedSuccess: "تم إنشاء التوكن بنجاح!",
    loginUrlLabel: "رابط تسجيل الدخول المباشر (Auto-Login URL):",
    rawTokenLabel: "رمز التوكن (NFToken String):",
    copy: "نسخ",
    copied: "تم النسخ!",
    openInNetflix: "فتح نتفلكس",
    qrTitle: "امسح للدخول السريع",
    qrSub: "وجّه كاميرا الهاتف للدخول فوراً",
    tvFastTitle: "تفعيل شاشة التلفزيون بهذا التوكن؟",
    tvFastDesc: "انتقل لتبويب التلفاز لفتح رابط التفعيل وإدخال رمز الشاشة مباشرة في نتفلكس.",
    btnJumpToTvText: "الانتقال لتفعيل التلفاز",
    tvMainTitle: "تفعيل تطبيق نتفلكس على أجهزة التلفاز (Netflix TV)",
    tvMainDesc: "افتح تطبيق نتفلكس على التلفاز، واختر 'تسجيل الدخول عبر المتصفح'، ثم استخدم الروابط أدناه لإدخال رمز التلفاز بنفسك على موقع نتفلكس.",
    methodRecommended: "الطريقة الموصى بها",
    method1Title: "تفعيل التلفاز المباشر بحساب التوكن (تلقائي)",
    method1Desc: "يقوم هذا الرابط بتسجيل الدخول للحساب مباشرة بدون باسورد ثم يفتح صفحة التفعيل (tv8) لتضع الرمز بنفسك.",
    btnOpenTvPage: "فتح صفحة التفعيل في نتفلكس (netflix.com/tv8)",
    tvNoTokenPrompt: "لم يتم توليد توكن بعد. يمكنك توليد توكن جاهز بنقرة واحدة فوراً:",
    btnGenAndActivate: "رابط تفعيل التلفاز",
    methodDirect: "رابط نتفلكس الرسمي",
    method2Title: "صفحة تفعيل نتفلكس الرسمية (tv8)",
    method2Desc: "إذا كان متصفحك أو هاتفك مسجلاً فيه الحساب بالفعل، افتح هذا الرابط مباشرة واكتب الرمز:",
    openTv8: "فتح netflix.com/tv8",
    method3Title: "مسح رمز الاستجابة السريعة (QR Code)",
    qrScanPhone: "امسح بكاميرا هاتفك لفتح صفحة التفعيل وكتابة الرمز مباشرة من الجوال",
    tvStepsTitle: "خطوات التفعيل في خطوتين فقط:",
    guideStep1Head: "افتح نتفلكس على التلفاز",
    guideStep1Body: "اختر 'تسجيل الدخول عبر المتصفح' وسيظهر لك رمز مكون من 8 أرقام أو حروف.",
    guideStep2HeadDirect: "افتح الرابط وأدخل الرمز في نتفلكس",
    guideStep2BodyDirect: "اضغط على الزر أعلاه أو امسح الباركود، ثم اكتب الرمز مباشرة في صفحة نتفلكس وسيعمل التلفاز فوراً!",
    historyTitle: "سجل التوكنات السابقة",
    clearHistory: "مسح السجل",
    thDate: "التاريخ",
    thAccount: "الحساب",
    thToken: "معاينة التوكن",
    thExpiry: "الانتهاء",
    thActions: "الإجراءات",
    emptyHistoryTitle: "لا يوجد توكنات مسجلة بعد",
    emptyHistoryDesc: "التوكنات التي ستقوم بإنشائها ستظهر هنا تلقائياً لسهولة الرجوع إليها وإعادة نسخها.",
    guide1Title: "كيفية استخراج كوكيز نتفلكس (Netflix Cookies)",
    g1s1: "تثبيت إضافة المتصفح:",
    g1s1p: "قم بتثبيت إضافة مثل Cookie-Editor على متصفحك.",
    g1s2: "فتح نتفلكس وتسجيل الدخول:",
    g1s2p: "توجه إلى موقع netflix.com وسجل الدخول بحسابك بنجاح.",
    g1s3: "تصدير الكوكيز:",
    g1s3p: "اضغط على أيقونة الإضافة، ثم اختر 'Export' بصيغة Netscape أو JSON.",
    guide2Title: "طريقة تفعيل تلفزيونات نتفلكس الذكية بالرابط",
    g2s1: "الحصول على الرمز من الشاشة:",
    g2s1p: "شغل تطبيق Netflix على التلفاز واختر 'تسجيل الدخول من المتصفح'. ستظهر شاشة تطلب زيارة netflix.com/tv8 مع رمز من 8 أرقام.",
    g2s2: "إدخال الرمز في موقعنا:",
    g2s2p: "انتقل لتبويب 'تفعيل تلفزيون نتفلكس'، واكتب الرمز الظاهر على شاشة التلفاز.",
    g2s3: "الضغط على تفعيل:",
    g2s3p: "افتح الرابط المتولد وسيسجل دخولك للتلفاز مباشرة!",
    tabMobile: "أندرويد/iOS",
    mobileMainTitle: "تفعيل أندرويد / iOS",
    mobileNoTokenPrompt: "لم يتم توليد توكن بعد. اضغط للتوليد.",
    btnGenAndActivateMobile: "توليد",
    btnOpenMobilePage: "فتح",
    mobileQrSub: "امسح لفتح الرابط على جهازك",
    adminPanelTitle: "لوحة تحكم المسؤول (Admin Panel)",
    adminPanelSubtitle: "إدارة مستودع الكوكيز وإضافة حسابات جديدة",
    enterAdminPass: "أدخل كلمة مرور الأدمن:",
    login: "دخول",
    defaultPassHint: "كلمة المرور الافتراضية هي admin123 (يمكنك تغييرها من الداخل)",
    addCookiesTab: "إضافة كوكيز جديدة",
    manageCookiesTab: "إدارة المستودع الحالي",
    settingsTab: "الإعدادات",
    accountNameLabel: "اسم / تصنيف الحساب (اختياري):",
    cookiesTextLabel: "ألصق الكوكيز هنا (يدعم كوكيز فردي أو جماعي متعدد):",
    importFromInputTxt: "استيراد من input.txt",
    multiCookieHint: "* يدعم صيغ Netscape، Raw String، وJSON. يمكنك فصل حسابات متعددة بكتابة --- بين كل كوكيز.",
    saveToPoolBtn: "إضافة إلى مستودع الكوكيز",
    totalCount: "إجمالي الكوكيز:",
    activeCount: "النشطة:",
    refresh: "تحديث",
    clearAll: "تفريغ المستودع",
    thName: "الاسم",
    thFormat: "الصيغة",
    thStatus: "الحالة",
    thUses: "الاستخدامات",
    thAdded: "تاريخ الإضافة",
    thOperations: "العمليات",
    changePassTitle: "تغيير كلمة مرور الأدمن",
    newPassLabel: "كلمة المرور الجديدة:",
    save: "حفظ",
    logout: "تسجيل الخروج من الأدمن"
  },
  en: {
    headerSubtitle: "NFToken Generator & TV Activator",
    serverOnline: "Server Online",
    availableCookies: "Available Cookies:",
    deviceQuotaLabel: "Daily Device Quota:",
    quotaHintPrefix: "Daily balance for this device:",
    adminPanel: "Admin Panel",
    heroBadge: "Smart Random Rotation System",
    heroTitle: "XNetflix — Auto-Login & TV Activation Studio",
    heroDesc: "",
    tabGenerator: "Netflix Activation",
    tabTv: "Netflix TV Activation",
    tabHistory: "History & Logs",
    tabGuide: "How to Use",
    poolSpotlightHeading: "Ready Cookies Pool:",
    cookiesWord: "account available",
    poolSpotlightSub: "",
    btnGenerateRandom: "Generate Netflix",
    btnHelperText: "* One click is all it takes! Generates your login link and QR code instantly.",
    toggleCustomCookie: "Have your own cookie? (Manual custom input)",
    loadFromInput: "Load from input.txt",
    clearInput: "Clear",
    btnGenerateCustomAction: "Generate from custom input above",
    waitingTitle: "Awaiting Token Generation",
    waitingDesc: "Click the generate button to draw a random active cookie and create your direct auto-login link and QR code.",
    f1: "Instant login without password",
    f2: "QR Code for quick mobile scanning",
    f3: "Direct activation for Smart TVs",
    tokenGeneratedSuccess: "NFToken Generated Successfully!",
    loginUrlLabel: "Direct Auto-Login URL:",
    rawTokenLabel: "NFToken String:",
    copy: "Copy",
    copied: "Copied!",
    openInNetflix: "Open in Netflix",
    qrTitle: "Scan for Instant Login",
    qrSub: "Point camera to log into Netflix instantly",
    tvFastTitle: "Activate TV with this token?",
    tvFastDesc: "Switch to the TV tab to open the activation link and enter your screen code directly on Netflix.",
    btnJumpToTvText: "Go to TV Activation",
    tvMainTitle: "Netflix TV App Activation",
    tvMainDesc: "Open Netflix on your TV, choose 'Sign In via Web/Browser', and use the links below to enter your TV code directly on Netflix.",
    methodRecommended: "Recommended Method",
    method1Title: "Direct TV Activation with Token",
    method1Desc: "Logs you into Netflix automatically and opens the tv8 page so you can enter the TV screen code yourself.",
    btnOpenTvPage: "Open Netflix TV8 Activation Page",
    tvNoTokenPrompt: "No token active yet. You can generate one with a single click now:",
    btnGenAndActivate: "TV Activation Link",
    methodDirect: "Official Netflix Page",
    method2Title: "Official Netflix Activation Page (tv8)",
    method2Desc: "If your browser or phone is already logged into your Netflix account, visit this page directly and type the 8-character code:",
    openTv8: "Open netflix.com/tv8",
    method3Title: "Scan QR Code",
    qrScanPhone: "Scan with your phone camera to open the activation page and enter the code directly from mobile",
    tvStepsTitle: "Activate in 2 Easy Steps:",
    guideStep1Head: "Open Netflix on TV",
    guideStep1Body: "Select 'Sign In via Web' on your TV to get your 8-digit code.",
    guideStep2HeadDirect: "Open Link & Enter Code",
    guideStep2BodyDirect: "Click the button above or scan the QR code, then enter the code directly on Netflix to stream immediately!",
    historyTitle: "Generated Tokens History",
    clearHistory: "Clear History",
    thDate: "Date",
    thAccount: "Account",
    thToken: "Token Preview",
    thExpiry: "Expiry",
    thActions: "Actions",
    emptyHistoryTitle: "No Tokens Recorded Yet",
    emptyHistoryDesc: "Tokens you generate will appear here automatically for easy copying and reuse.",
    guide1Title: "How to Extract Netflix Cookies",
    g1s1: "Install Browser Extension:",
    g1s1p: "Install Cookie-Editor on your browser.",
    g1s2: "Log into Netflix:",
    g1s2p: "Go to netflix.com and log into your account.",
    g1s3: "Export Cookies:",
    g1s3p: "Click the extension icon, and export as Netscape or JSON.",
    guide2Title: "How to Activate Netflix Smart TVs",
    g2s1: "Get TV Code from Screen:",
    g2s1p: "Open Netflix on TV. Choose sign in via web. Note the 8-digit code.",
    g2s2: "Enter Code in Studio:",
    g2s2p: "Switch to TV tab, type the code.",
    g2s3: "Click Activate:",
    g2s3p: "Open the generated link to activate immediately!",
    tabMobile: "Android/iOS",
    mobileMainTitle: "Android / iOS Activation",
    mobileNoTokenPrompt: "No token yet. Generate one to get your activation link.",
    btnGenAndActivateMobile: "Generate",
    btnOpenMobilePage: "Open",
    mobileQrSub: "Scan to open on your device",
    adminPanelTitle: "Admin Panel",
    adminPanelSubtitle: "Manage Cookie Pool & Add Accounts",
    enterAdminPass: "Enter Admin Password:",
    login: "Login",
    defaultPassHint: "Default password is admin123 (changeable inside)",
    addCookiesTab: "Add New Cookies",
    manageCookiesTab: "Manage Pool Inventory",
    settingsTab: "Settings",
    accountNameLabel: "Account Name / Label (Optional):",
    cookiesTextLabel: "Paste Cookies Here (Supports Single or Multi-Account):",
    importFromInputTxt: "Import from input.txt",
    multiCookieHint: "* Supports Netscape, Raw, and JSON. Separate multiple accounts with --- on a new line.",
    saveToPoolBtn: "Add to Cookie Pool",
    totalCount: "Total Cookies:",
    activeCount: "Active:",
    refresh: "Refresh",
    clearAll: "Clear Pool",
    thName: "Name",
    thFormat: "Format",
    thStatus: "Status",
    thUses: "Uses",
    thAdded: "Added Date",
    thOperations: "Operations",
    changePassTitle: "Change Admin Password",
    newPassLabel: "New Password:",
    save: "Save",
    logout: "Admin Logout"
  }
};

let currentLang = "en";
let lastGeneratedToken = null;
let adminAuthToken = sessionStorage.getItem("adminAuthToken") || null;

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  applyTranslations();
  setupLanguage();
  setupTabs();
  setupPoolGeneration();
  setupCustomCookieToggle();
  setupTvActivation();
  setupMobileActivation();
  setupAdminPanel();
  loadPoolStatus();
  loadHistory();
  loadDeviceQuota();
  // Poll pool status every 20 seconds
  setInterval(loadPoolStatus, 20000);
});

// Device Identification & Daily Quota Management
function getOrCreateDeviceId() {
  let devId = localStorage.getItem("nftoken_device_id");
  if (!devId || devId.length < 16) {
    devId = "dev_" + "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
    localStorage.setItem("nftoken_device_id", devId);
  }
  try {
    document.cookie = `device_id=${encodeURIComponent(devId)}; path=/; max-age=31536000; SameSite=Lax`;
  } catch (e) {}
  return devId;
}

async function loadDeviceQuota() {
  try {
    const devId = getOrCreateDeviceId();
    const res = await fetch("/api/device/quota", {
      headers: { "X-Device-Id": devId }
    });
    const data = await res.json();
    if (data.success) {
      updateDeviceQuotaUI(data.remaining, data.limit, data.can_activate);
    }
  } catch (e) {
    console.warn("Could not retrieve quota:", e);
  }
}

function updateDeviceQuotaUI(remaining, limit, canActivate) {
  const countBadge = document.getElementById("headerQuotaCount");
  const quotaBadge = document.getElementById("headerQuotaBadge");
  const quotaHint = document.getElementById("quotaRemainingHint");
  const pillHint = document.getElementById("quotaPillHint");

  if (countBadge) {
    countBadge.textContent = `${remaining} / ${limit}`;
  }

  if (quotaBadge) {
    quotaBadge.classList.remove("quota-warning", "quota-exhausted");
    if (remaining === 0) {
      quotaBadge.classList.add("quota-exhausted");
    } else if (remaining === 1) {
      quotaBadge.classList.add("quota-warning");
    }
  }

  if (quotaHint) {
    if (currentLang === "ar") {
      quotaHint.textContent = remaining > 0 
        ? `${remaining} من ${limit} تفعيلات متاحة` 
        : "استنفدت الحد اليومي (0 من 3)";
    } else {
      quotaHint.textContent = remaining > 0 
        ? `${remaining} of ${limit} activations left` 
        : "Daily quota reached (0 of 3)";
    }
  }

  if (pillHint) {
    if (remaining === 0) {
      pillHint.classList.add("exhausted");
    } else {
      pillHint.classList.remove("exhausted");
    }
  }
}

// Toast notification helper
function showToast(message, type = "info") {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    toast.style.transition = "0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// Copy to Clipboard
async function copyToClipboard(text, btnElement = null) {
  try {
    await navigator.clipboard.writeText(text);
    showToast(currentLang === "ar" ? "تم النسخ إلى الحافظة بنجاح!" : "Copied to clipboard!", "success");
    if (btnElement) {
      const originalHTML = btnElement.innerHTML;
      btnElement.innerHTML = `<span>${I18N[currentLang].copied}</span>`;
      setTimeout(() => {
        btnElement.innerHTML = originalHTML;
      }, 2000);
    }
  } catch (err) {
    showToast(currentLang === "ar" ? "فشل النسخ التلقائي" : "Failed to copy", "error");
  }
}

// Language Engine
function setupLanguage() {
  const langBtn = document.getElementById("langSwitchBtn");
  const langLabel = document.getElementById("langLabel");
  if (!langBtn) return;

  langBtn.addEventListener("click", () => {
    currentLang = currentLang === "ar" ? "en" : "ar";
    document.documentElement.lang = currentLang;
    document.documentElement.dir = currentLang === "ar" ? "rtl" : "ltr";
    if (langLabel) langLabel.textContent = currentLang === "ar" ? "English" : "العربية";
    applyTranslations();
  });
}

function applyTranslations() {
  const dict = I18N[currentLang];
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (dict[key]) {
      el.textContent = dict[key];
    }
  });
  loadDeviceQuota();
}

// Tabs
function setupTabs() {
  const tabBtns = document.querySelectorAll(".tab-btn");
  const tabContents = document.querySelectorAll(".tab-content");

  tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-tab");
      tabBtns.forEach(b => b.classList.remove("active"));
      tabContents.forEach(c => c.classList.remove("active"));

      btn.classList.add("active");
      const targetContent = document.getElementById(targetId);
      if (targetContent) {
        targetContent.classList.add("active");
      }

      if (targetId === "tab-history") {
        loadHistory();
      }
    });
  });

  const btnJumpToTv = document.getElementById("btnJumpToTv");
  if (btnJumpToTv) {
    btnJumpToTv.addEventListener("click", () => {
      const tvTabBtn = document.getElementById("tabBtnTv");
      if (tvTabBtn) tvTabBtn.click();
    });
  }
}

// Pool Status Poller
async function loadPoolStatus() {
  try {
    const res = await fetch("/api/pool/status");
    const data = await res.json();
    if (data.success) {
      const activeCount = data.active_count || 0;
      const headerCountEl = document.getElementById("headerPoolCount");
      const spotCountEl = document.getElementById("poolSpotlightCount");
      const adminCountEl = document.getElementById("adminPoolCounter");

      if (headerCountEl) headerCountEl.textContent = activeCount;
      if (spotCountEl) spotCountEl.textContent = activeCount;
      if (adminCountEl) adminCountEl.textContent = data.total_count || 0;

      const spotBadge = document.getElementById("poolSpotlightBadge");
      if (spotBadge) {
        if (activeCount === 0) {
          spotBadge.style.background = "#ef4444";
        } else {
          spotBadge.style.background = "var(--netflix-red)";
        }
      }
    }
  } catch (e) {
    console.error("Pool status check failed:", e);
  }
}

// 1-Click Pool Generator
function setupPoolGeneration() {
  const btnGenerateFromPool = document.getElementById("btnGenerateFromPool");
  const poolBtnSpinner = document.getElementById("poolBtnSpinner");

  const resultPlaceholder = document.getElementById("resultPlaceholder");
  const activeResultBox = document.getElementById("activeResultBox");
  const resultLoginUrl = document.getElementById("resultLoginUrl");
  const resultRawToken = document.getElementById("resultRawToken");
  const resultQrImg = document.getElementById("resultQrImg");
  const btnOpenUrl = document.getElementById("btnOpenUrl");
  const btnOpenBrowse = document.getElementById("btnOpenBrowse");

  const btnCopyUrl = document.getElementById("btnCopyUrl");
  const btnCopyToken = document.getElementById("btnCopyToken");

  btnCopyUrl.addEventListener("click", () => {
    if (resultLoginUrl.value) copyToClipboard(resultLoginUrl.value, btnCopyUrl);
  });

  btnCopyToken.addEventListener("click", () => {
    if (resultRawToken.value) copyToClipboard(resultRawToken.value, btnCopyToken);
  });

  btnGenerateFromPool.addEventListener("click", async () => {
    poolBtnSpinner.classList.add("show");
    btnGenerateFromPool.disabled = true;

    try {
      const devId = getOrCreateDeviceId();
      const response = await fetch("/api/generate-from-pool", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "X-Device-Id": devId
        }
      });

      const data = await response.json();

      if (data.success) {
        lastGeneratedToken = data.token;
        resultLoginUrl.value = data.login_url;
        resultRawToken.value = data.token;
        if (btnOpenUrl) btnOpenUrl.href = data.login_url;
        if (btnOpenBrowse) btnOpenBrowse.href = data.browse_url || data.login_url;

        if (data.login_qr) {
          resultQrImg.src = data.login_qr;
        }

        resultPlaceholder.style.display = "none";
        activeResultBox.classList.remove("hidden");

        updateTvTabTokenState(data.token, data.tv_activation_url, data.tv_qr);
        updateMobileTabTokenState(data.token, data.unsupported_url, data.unsupported_qr);
        showToast(currentLang === "ar" ? "تم توليد التوكن بنجاح من المستودع!" : "Token generated from pool!", "success");
        loadHistory();
        loadPoolStatus();
        loadDeviceQuota();
      } else {
        if (response.status === 429 || data.limit_reached) {
          showToast(
            currentLang === "ar"
              ? "لقد استنفدت الحد اليومي لجهازك (3 تفعيلات باليوم). يتجدد الرصيد غداً بإذن الله!"
              : "Daily limit reached for this device (3 activations/day). Resets tomorrow!",
            "error"
          );
        } else {
          showToast(data.error || (currentLang === "ar" ? "تعذر توليد التوكن" : "Token generation failed"), "error");
        }
        loadDeviceQuota();
      }
    } catch (err) {
      showToast(currentLang === "ar" ? "حدث خطأ في الاتصال بالخادم" : "Server connection error", "error");
    } finally {
      poolBtnSpinner.classList.remove("show");
      btnGenerateFromPool.disabled = false;
    }
  });
}

// Custom Cookie Accordion
function setupCustomCookieToggle() {
  const btnToggle = document.getElementById("btnToggleCustomCookie");
  const body = document.getElementById("customCookieBody");
  const chevron = document.getElementById("accChevron");
  const cookieInput = document.getElementById("cookieInput");
  const btnLoadInput = document.getElementById("btnLoadInput");
  const btnClearInput = document.getElementById("btnClearInput");
  const btnGenerateCustom = document.getElementById("btnGenerateCustom");
  const customBtnSpinner = document.getElementById("customBtnSpinner");

  btnToggle.addEventListener("click", () => {
    body.classList.toggle("hidden");
    chevron.classList.toggle("rotated");
  });

  btnLoadInput.addEventListener("click", async () => {
    try {
      const res = await fetch("/api/load-input");
      const data = await res.json();
      if (data.success && data.content) {
        cookieInput.value = data.content;
        showToast(currentLang === "ar" ? "تم تحميل الكوكيز من input.txt" : "Loaded from input.txt", "success");
      }
    } catch (e) {
      showToast("Error loading file", "error");
    }
  });

  btnClearInput.addEventListener("click", () => {
    cookieInput.value = "";
    showToast(currentLang === "ar" ? "تم مسح الحقل" : "Cleared", "info");
  });

  btnGenerateCustom.addEventListener("click", async () => {
    const val = cookieInput.value.trim();
    if (!val) {
      showToast(currentLang === "ar" ? "يرجى لصق الكوكيز أولاً" : "Paste your cookie first", "error");
      return;
    }

    customBtnSpinner.classList.add("show");
    btnGenerateCustom.disabled = true;

    try {
      const devId = getOrCreateDeviceId();
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "X-Device-Id": devId
        },
        body: JSON.stringify({ cookie: val })
      });

      const data = await response.json();
      if (data.success) {
        lastGeneratedToken = data.token;
        document.getElementById("resultLoginUrl").value = data.login_url;
        document.getElementById("resultRawToken").value = data.token;
        document.getElementById("btnOpenUrl").href = data.login_url;
        const customBrowseBtn = document.getElementById("btnOpenBrowse");
        if (customBrowseBtn) customBrowseBtn.href = data.browse_url || data.login_url;

        if (data.login_qr) {
          document.getElementById("resultQrImg").src = data.login_qr;
        }

        document.getElementById("resultPlaceholder").style.display = "none";
        document.getElementById("activeResultBox").classList.remove("hidden");

        updateTvTabTokenState(data.token, data.tv_activation_url, data.tv_qr);
        updateMobileTabTokenState(data.token, data.unsupported_url, data.unsupported_qr);
        showToast(currentLang === "ar" ? "تم إنشاء التوكن بنجاح!" : "Token generated!", "success");
        loadHistory();
        loadDeviceQuota();
      } else {
        if (response.status === 429 || data.limit_reached) {
          showToast(
            currentLang === "ar"
              ? "لقد استنفدت الحد اليومي لجهازك (3 تفعيلات باليوم). يتجدد الرصيد غداً بإذن الله!"
              : "Daily limit reached for this device (3 activations/day). Resets tomorrow!",
            "error"
          );
        } else {
          showToast(data.error || "Failed", "error");
        }
        loadDeviceQuota();
      }
    } catch (e) {
      showToast("Server error", "error");
    } finally {
      customBtnSpinner.classList.remove("show");
      btnGenerateCustom.disabled = false;
    }
  });
}

// TV Tab Token Sync
function updateTvTabTokenState(token, activationUrl, qrCode) {
  const tvTokenActiveState = document.getElementById("tvTokenActiveState");
  const tvNoTokenState = document.getElementById("tvNoTokenState");
  const tvAttachedTokenPreview = document.getElementById("tvAttachedTokenPreview");
  const btnOpenTvDirect = document.getElementById("btnOpenTvDirect");
  const tvDirectLinkInput = document.getElementById("tvDirectLinkInput");
  const tvQrImage = document.getElementById("tvQrImage");

  if (token) {
    lastGeneratedToken = token;
    const url = activationUrl || `https://www.netflix.com/tv8?nftoken=${encodeURIComponent(token)}`;

    if (tvAttachedTokenPreview) {
      tvAttachedTokenPreview.textContent = (currentLang === "ar" ? "توكن جاهز ومربوط: " : "Active Token: ") + token.slice(0, 10) + "..." + token.slice(-6);
    }
    if (btnOpenTvDirect) {
      btnOpenTvDirect.href = url;
    }
    if (tvDirectLinkInput) {
      tvDirectLinkInput.value = url;
    }
    if (tvQrImage) {
      if (qrCode) {
        tvQrImage.src = qrCode;
      } else {
        tvQrImage.src = `/api/qr?data=${encodeURIComponent(url)}`;
      }
    }

    if (tvTokenActiveState) tvTokenActiveState.classList.remove("hidden");
    if (tvNoTokenState) tvNoTokenState.classList.add("hidden");
  } else {
    if (tvTokenActiveState) tvTokenActiveState.classList.add("hidden");
    if (tvNoTokenState) tvNoTokenState.classList.remove("hidden");
  }
}

// Mobile Tab Token Sync
function updateMobileTabTokenState(token, unsupportedUrl, qrCode) {
  const mobileTokenActiveState = document.getElementById("mobileTokenActiveState");
  const mobileNoTokenState = document.getElementById("mobileNoTokenState");
  const mobileAttachedTokenPreview = document.getElementById("mobileAttachedTokenPreview");
  const btnOpenMobileDirect = document.getElementById("btnOpenMobileDirect");
  const mobileDirectLinkInput = document.getElementById("mobileDirectLinkInput");
  const mobileQrImage = document.getElementById("mobileQrImage");

  if (token) {
    const url = unsupportedUrl || `https://www.netflix.com/unsupported?nftoken=${encodeURIComponent(token)}`;

    if (mobileAttachedTokenPreview) {
      mobileAttachedTokenPreview.textContent = (currentLang === "ar" ? "توكن جاهز ومربوط: " : "Active Token: ") + token.slice(0, 10) + "..." + token.slice(-6);
    }
    if (btnOpenMobileDirect) {
      btnOpenMobileDirect.href = url;
    }
    if (mobileDirectLinkInput) {
      mobileDirectLinkInput.value = url;
    }
    if (mobileQrImage) {
      if (qrCode) {
        mobileQrImage.src = qrCode;
      } else {
        mobileQrImage.src = `/api/qr?data=${encodeURIComponent(url)}`;
      }
    }

    if (mobileTokenActiveState) mobileTokenActiveState.classList.remove("hidden");
    if (mobileNoTokenState) mobileNoTokenState.classList.add("hidden");
  } else {
    if (mobileTokenActiveState) mobileTokenActiveState.classList.add("hidden");
    if (mobileNoTokenState) mobileNoTokenState.classList.remove("hidden");
  }
}

// TV Activation Handler
function setupTvActivation() {
  const tvDirectLinkInput = document.getElementById("tvDirectLinkInput");
  const btnCopyTvDirectLink = document.getElementById("btnCopyTvDirectLink");
  const btnCopyOfficialLink = document.getElementById("btnCopyOfficialLink");
  const btnGenerateForTv = document.getElementById("btnGenerateForTv");
  const tvGenSpinner = document.getElementById("tvGenSpinner");

  if (btnCopyTvDirectLink) {
    btnCopyTvDirectLink.addEventListener("click", () => {
      if (tvDirectLinkInput && tvDirectLinkInput.value) {
        copyToClipboard(tvDirectLinkInput.value, btnCopyTvDirectLink);
      }
    });
  }

  if (btnCopyOfficialLink) {
    btnCopyOfficialLink.addEventListener("click", () => {
      copyToClipboard("https://www.netflix.com/tv8", btnCopyOfficialLink);
    });
  }

  if (btnGenerateForTv) {
    btnGenerateForTv.addEventListener("click", async () => {
      if (tvGenSpinner) tvGenSpinner.classList.add("show");
      btnGenerateForTv.disabled = true;

      try {
        const devId = getOrCreateDeviceId();
        const response = await fetch("/api/generate-from-pool", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Device-Id": devId
          }
        });

        const data = await response.json();

        if (data.success) {
          lastGeneratedToken = data.token;

          // Update Generator Tab as well
          const resultLoginUrl = document.getElementById("resultLoginUrl");
          const resultRawToken = document.getElementById("resultRawToken");
          const btnOpenUrl = document.getElementById("btnOpenUrl");
          const btnOpenBrowse = document.getElementById("btnOpenBrowse");
          const resultQrImg = document.getElementById("resultQrImg");
          const resultPlaceholder = document.getElementById("resultPlaceholder");
          const activeResultBox = document.getElementById("activeResultBox");

          if (resultLoginUrl) resultLoginUrl.value = data.login_url;
          if (resultRawToken) resultRawToken.value = data.token;
          if (btnOpenUrl) btnOpenUrl.href = data.login_url;
          if (btnOpenBrowse) btnOpenBrowse.href = data.browse_url || data.login_url;
          if (resultQrImg && data.login_qr) resultQrImg.src = data.login_qr;
          if (resultPlaceholder) resultPlaceholder.style.display = "none";
          if (activeResultBox) activeResultBox.classList.remove("hidden");

          // Update TV tab
          updateTvTabTokenState(data.token, data.tv_activation_url, data.tv_qr);
          updateMobileTabTokenState(data.token, data.unsupported_url, data.unsupported_qr);

          showToast(currentLang === "ar" ? "تم إنشاء التوكن وتجهيز رابط تفعيل التلفاز بنجاح!" : "Token generated & TV activation ready!", "success");

          loadHistory();
          loadPoolStatus();
          loadDeviceQuota();
        } else {
          if (response.status === 429 || data.limit_reached) {
            showToast(
              currentLang === "ar"
                ? "لقد استنفدت الحد اليومي لجهازك (3 تفعيلات باليوم). يتجدد الرصيد غداً بإذن الله!"
                : "Daily limit reached for this device (3 activations/day). Resets tomorrow!",
              "error"
            );
          } else {
            showToast(data.error || (currentLang === "ar" ? "تعذر توليد التوكن" : "Token generation failed"), "error");
          }
          loadDeviceQuota();
        }
      } catch (err) {
        showToast(currentLang === "ar" ? "حدث خطأ في الاتصال بالخادم" : "Server connection error", "error");
      } finally {
        if (tvGenSpinner) tvGenSpinner.classList.remove("show");
        btnGenerateForTv.disabled = false;
      }
    });
  }
}

// Mobile Activation Handler
function setupMobileActivation() {
  const mobileDirectLinkInput = document.getElementById("mobileDirectLinkInput");
  const btnCopyMobileDirectLink = document.getElementById("btnCopyMobileDirectLink");
  const btnGenerateForMobile = document.getElementById("btnGenerateForMobile");
  const mobileGenSpinner = document.getElementById("mobileGenSpinner");

  if (btnCopyMobileDirectLink) {
    btnCopyMobileDirectLink.addEventListener("click", () => {
      if (mobileDirectLinkInput && mobileDirectLinkInput.value) {
        copyToClipboard(mobileDirectLinkInput.value, btnCopyMobileDirectLink);
      }
    });
  }

  if (btnGenerateForMobile) {
    btnGenerateForMobile.addEventListener("click", async () => {
      if (mobileGenSpinner) mobileGenSpinner.classList.add("show");
      btnGenerateForMobile.disabled = true;

      try {
        const devId = getOrCreateDeviceId();
        const response = await fetch("/api/generate-from-pool", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Device-Id": devId
          }
        });

        const data = await response.json();

        if (data.success) {
          lastGeneratedToken = data.token;

          // Update Generator Tab as well
          const resultLoginUrl = document.getElementById("resultLoginUrl");
          const resultRawToken = document.getElementById("resultRawToken");
          const btnOpenUrl = document.getElementById("btnOpenUrl");
          const btnOpenBrowse = document.getElementById("btnOpenBrowse");
          const resultQrImg = document.getElementById("resultQrImg");
          const resultPlaceholder = document.getElementById("resultPlaceholder");
          const activeResultBox = document.getElementById("activeResultBox");

          if (resultLoginUrl) resultLoginUrl.value = data.login_url;
          if (resultRawToken) resultRawToken.value = data.token;
          if (btnOpenUrl) btnOpenUrl.href = data.login_url;
          if (btnOpenBrowse) btnOpenBrowse.href = data.browse_url || data.login_url;
          if (resultQrImg && data.login_qr) resultQrImg.src = data.login_qr;
          if (resultPlaceholder) resultPlaceholder.style.display = "none";
          if (activeResultBox) activeResultBox.classList.remove("hidden");

          // Update TV tab
          updateTvTabTokenState(data.token, data.tv_activation_url, data.tv_qr);
          // Update Mobile tab
          updateMobileTabTokenState(data.token, data.unsupported_url, data.unsupported_qr);

          showToast(currentLang === "ar" ? "تم إنشاء التوكن وتجهيز رابط تفعيل الهاتف بنجاح!" : "Token generated & mobile activation ready!", "success");

          loadHistory();
          loadPoolStatus();
          loadDeviceQuota();
        } else {
          if (response.status === 429 || data.limit_reached) {
            showToast(
              currentLang === "ar"
                ? "لقد استنفدت الحد اليومي لجهازك (3 تفعيلات باليوم). يتجدد الرصيد غداً بإذن الله!"
                : "Daily limit reached for this device (3 activations/day). Resets tomorrow!",
              "error"
            );
          } else {
            showToast(data.error || (currentLang === "ar" ? "تعذر توليد التوكن" : "Token generation failed"), "error");
          }
          loadDeviceQuota();
        }
      } catch (err) {
        showToast(currentLang === "ar" ? "حدث خطأ في الاتصال بالخادم" : "Server connection error", "error");
      } finally {
        if (mobileGenSpinner) mobileGenSpinner.classList.remove("show");
        btnGenerateForMobile.disabled = false;
      }
    });
  }
}

// History
async function loadHistory() {
  const historyTableBody = document.getElementById("historyTableBody");
  if (!historyTableBody) return;
  const emptyHistoryState = document.getElementById("emptyHistoryState");
  const historyCounter = document.getElementById("historyCounter");
  const btnClearHistory = document.getElementById("btnClearHistory");

  try {
    const res = await fetch("/api/history");
    const data = await res.json();

    if (data.success && data.history && data.history.length > 0) {
      historyCounter.textContent = data.history.length;
      emptyHistoryState.style.display = "none";
      historyTableBody.innerHTML = "";

      data.history.forEach(item => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td style="color: var(--text-muted); font-size: 0.8rem;">${item.created_at || "-"}</td>
          <td><span style="color: #a7f3d0; font-size: 0.78rem; background: rgba(16,185,129,0.1); padding: 2px 6px; border-radius: 4px;">${item.account_name || "Pool"}</span></td>
          <td><code style="color: #93c5fd; background: rgba(255,255,255,0.04); padding: 2px 6px; border-radius: 4px;">${item.token_preview}</code></td>
          <td style="color: var(--accent-gold); font-size: 0.8rem;">${item.expires_formatted || "-"}</td>
          <td>
            <div class="history-actions">
              <button class="btn-copy btn-mini" title="Copy" onclick="copyToClipboard('${item.login_url}')">${I18N[currentLang].copy}</button>
              <a href="${item.login_url}" target="_blank" class="btn-open-link btn-mini">${I18N[currentLang].open}</a>
            </div>
          </td>
        `;
        historyTableBody.appendChild(tr);
      });
    } else {
      historyCounter.textContent = "0";
      historyTableBody.innerHTML = "";
      emptyHistoryState.style.display = "block";
    }
  } catch (e) {
    console.error("Failed to load history:", e);
  }

  if (btnClearHistory) {
    btnClearHistory.onclick = async () => {
      if (confirm(currentLang === "ar" ? "هل أنت متأكد من رغبتك في مسح السجل؟" : "Clear history?")) {
        await fetch("/api/clear-history", { method: "POST" });
        loadHistory();
        showToast(currentLang === "ar" ? "تم مسح السجل" : "History cleared", "info");
      }
    };
  }
}

// ==========================================================================
// ADMIN PANEL ENGINE
// ==========================================================================
function setupAdminPanel() {
  const modalOverlay = document.getElementById("adminModalOverlay");
  const btnOpenModal = document.getElementById("btnOpenAdminModal");
  if (!modalOverlay || !btnOpenModal) {
    return;
  }
  const btnCloseModal = document.getElementById("btnCloseAdminModal");

  const loginView = document.getElementById("adminLoginView");
  const dashboardView = document.getElementById("adminDashboardView");
  const adminPassInput = document.getElementById("adminPassInput");
  const btnAdminLogin = document.getElementById("btnAdminLogin");
  const adminLoginSpinner = document.getElementById("adminLoginSpinner");

  // Open modal
  btnOpenModal.addEventListener("click", () => {
    modalOverlay.classList.remove("hidden");
    if (adminAuthToken) {
      showAdminDashboard();
    } else {
      showAdminLogin();
    }
  });

  // Close modal
  btnCloseModal.addEventListener("click", () => {
    modalOverlay.classList.add("hidden");
  });

  modalOverlay.addEventListener("click", (e) => {
    if (e.target === modalOverlay) {
      modalOverlay.classList.add("hidden");
    }
  });

  // Admin Login Action
  btnAdminLogin.addEventListener("click", handleAdminLogin);
  adminPassInput.addEventListener("keyup", (e) => {
    if (e.key === "Enter") handleAdminLogin();
  });

  async function handleAdminLogin() {
    const pass = adminPassInput.value.trim();
    if (!pass) return;

    adminLoginSpinner.classList.add("show");
    btnAdminLogin.disabled = true;

    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pass })
      });
      const data = await res.json();

      if (data.success) {
        adminAuthToken = data.token;
        sessionStorage.setItem("adminAuthToken", adminAuthToken);
        adminPassInput.value = "";
        showAdminDashboard();
        showToast(currentLang === "ar" ? "تم تسجيل دخول المسؤول بنجاح" : "Admin logged in", "success");
      } else {
        showToast(data.error || "Password incorrect", "error");
      }
    } catch (e) {
      showToast("Error", "error");
    } finally {
      adminLoginSpinner.classList.remove("show");
      btnAdminLogin.disabled = false;
    }
  }

  function showAdminLogin() {
    loginView.classList.remove("hidden");
    dashboardView.classList.add("hidden");
  }

  function showAdminDashboard() {
    loginView.classList.add("hidden");
    dashboardView.classList.remove("hidden");
    loadAdminInventory();
  }

  // Admin Subtabs navigation
  const subtabBtns = document.querySelectorAll(".admin-subtab-btn");
  const subtabContents = document.querySelectorAll(".admin-atab-content");

  subtabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-atab");
      subtabBtns.forEach(b => b.classList.remove("active"));
      subtabContents.forEach(c => c.classList.remove("active"));

      btn.classList.add("active");
      const targetContent = document.getElementById(targetId);
      if (targetContent) targetContent.classList.add("active");

      if (targetId === "atab-inventory") {
        loadAdminInventory();
      }
    });
  });

  // Add Cookies from Admin
  const btnAdminSaveCookies = document.getElementById("btnAdminSaveCookies");
  const adminCookiesText = document.getElementById("adminCookiesText");
  const adminAccountName = document.getElementById("adminAccountName");
  const adminSaveSpinner = document.getElementById("adminSaveSpinner");

  btnAdminSaveCookies.addEventListener("click", async () => {
    const text = adminCookiesText.value.trim();
    if (!text) {
      showToast(currentLang === "ar" ? "يرجى إدخال نص الكوكيز" : "Enter cookies text", "error");
      return;
    }

    adminSaveSpinner.classList.add("show");
    btnAdminSaveCookies.disabled = true;

    try {
      const res = await fetch("/api/admin/cookies/add", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminAuthToken}`
        },
        body: JSON.stringify({
          cookies_text: text,
          name: adminAccountName.value.trim()
        })
      });

      const data = await res.json();
      if (data.success) {
        adminCookiesText.value = "";
        adminAccountName.value = "";
        showToast(data.message || "Added successfully!", "success");
        loadAdminInventory();
        loadPoolStatus();
      } else {
        showToast(data.error || "Failed to add cookies", "error");
      }
    } catch (e) {
      showToast("Error", "error");
    } finally {
      adminSaveSpinner.classList.remove("show");
      btnAdminSaveCookies.disabled = false;
    }
  });

  // Import from input.txt in Admin
  const btnAdminImportInput = document.getElementById("btnAdminImportInput");
  btnAdminImportInput.addEventListener("click", async () => {
    try {
      const res = await fetch("/api/admin/cookies/import-input", {
        method: "POST",
        headers: { "Authorization": `Bearer ${adminAuthToken}` }
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message, "success");
        loadAdminInventory();
        loadPoolStatus();
      } else {
        showToast(data.error || "Import failed", "error");
      }
    } catch (e) {
      showToast("Error", "error");
    }
  });

  // Refresh Inventory
  const btnRefreshInventory = document.getElementById("btnRefreshInventory");
  btnRefreshInventory.addEventListener("click", loadAdminInventory);

  // Clear All Pool
  const btnClearAllPool = document.getElementById("btnClearAllPool");
  btnClearAllPool.addEventListener("click", async () => {
    if (confirm(currentLang === "ar" ? "هل أنت متأكد من تفريغ كافة الكوكيز من المستودع؟" : "Clear all cookies in pool?")) {
      try {
        const res = await fetch("/api/admin/cookies/clear", {
          method: "POST",
          headers: { "Authorization": `Bearer ${adminAuthToken}` }
        });
        const data = await res.json();
        if (data.success) {
          showToast(data.message, "info");
          loadAdminInventory();
          loadPoolStatus();
        }
      } catch (e) {
        showToast("Error", "error");
      }
    }
  });

  // Change Password
  const btnChangeAdminPass = document.getElementById("btnChangeAdminPass");
  const newAdminPassInput = document.getElementById("newAdminPassInput");
  btnChangeAdminPass.addEventListener("click", async () => {
    const newPass = newAdminPassInput.value.trim();
    if (!newPass) return;

    try {
      const res = await fetch("/api/admin/change-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminAuthToken}`
        },
        body: JSON.stringify({ new_password: newPass })
      });
      const data = await res.json();
      if (data.success) {
        adminAuthToken = newPass;
        sessionStorage.setItem("adminAuthToken", adminAuthToken);
        newAdminPassInput.value = "";
        showToast(data.message, "success");
      } else {
        showToast(data.error || "Failed", "error");
      }
    } catch (e) {
      showToast("Error", "error");
    }
  });

  // Logout Admin
  const btnAdminLogout = document.getElementById("btnAdminLogout");
  btnAdminLogout.addEventListener("click", () => {
    adminAuthToken = null;
    sessionStorage.removeItem("adminAuthToken");
    showAdminLogin();
    showToast(currentLang === "ar" ? "تم تسجيل الخروج" : "Logged out", "info");
  });
}

// Load Inventory Table
async function loadAdminInventory() {
  const tableBody = document.getElementById("adminInventoryTableBody");
  const totalCountEl = document.getElementById("invTotalCount");
  const activeCountEl = document.getElementById("invActiveCount");

  try {
    const res = await fetch("/api/admin/cookies", {
      headers: { "Authorization": `Bearer ${adminAuthToken}` }
    });
    const data = await res.json();

    if (data.success && data.cookies) {
      const activeCount = data.cookies.filter(c => c.status === "active").length;
      totalCountEl.textContent = data.cookies.length;
      activeCountEl.textContent = activeCount;

      tableBody.innerHTML = "";
      data.cookies.forEach(item => {
        const tr = document.createElement("tr");

        let statusBadge = `<span class="status-badge-active">نشط</span>`;
        if (item.status === "inactive") {
          statusBadge = `<span class="status-badge-inactive">معطل</span>`;
        } else if (item.status === "expired") {
          statusBadge = `<span class="status-badge-expired">منتهي</span>`;
        }

        tr.innerHTML = `
          <td><strong>${item.name || "حساب"}</strong><br><small style="color: var(--text-dim); font-family: monospace;">${item.netflix_id_preview || ""}</small></td>
          <td><span style="font-size: 0.75rem; color: var(--text-muted);">${item.format || "raw"}</span></td>
          <td>${statusBadge}</td>
          <td><strong style="color: var(--accent-gold);">${item.usage_count || 0}</strong></td>
          <td style="font-size: 0.78rem; color: var(--text-dim);">${item.added_at || "-"}</td>
          <td>
            <div class="admin-table-ops">
              <button class="btn-op" title="فحص" onclick="testCookie('${item.id}', this)">فحص</button>
              <button class="btn-op" title="تبديل" onclick="toggleCookie('${item.id}')">تبديل</button>
              <button class="btn-op btn-op-danger" title="حذف" onclick="deleteCookie('${item.id}')">حذف</button>
            </div>
          </td>
        `;
        tableBody.appendChild(tr);
      });
    }
  } catch (e) {
    console.error("Inventory load failed:", e);
  }
}

// Global actions for inventory buttons
window.testCookie = async function(id, btn) {
  if (btn) btn.textContent = currentLang === "ar" ? "جاري الفحص..." : "Testing...";
  try {
    const res = await fetch("/api/admin/cookies/test", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${adminAuthToken}`
      },
      body: JSON.stringify({ id })
    });
    const data = await res.json();
    if (data.success) {
      showToast(data.message, "success");
    } else {
      showToast(data.error || "Cookie invalid or expired", "error");
    }
    loadAdminInventory();
    loadPoolStatus();
  } catch (e) {
    showToast("Test failed", "error");
  } finally {
    if (btn) btn.textContent = "فحص";
  }
};

window.toggleCookie = async function(id) {
  try {
    const res = await fetch("/api/admin/cookies/toggle", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${adminAuthToken}`
      },
      body: JSON.stringify({ id })
    });
    const data = await res.json();
    if (data.success) {
      loadAdminInventory();
      loadPoolStatus();
    }
  } catch (e) {
    showToast("Toggle failed", "error");
  }
};

window.deleteCookie = async function(id) {
  if (confirm(currentLang === "ar" ? "هل تريد بالتأكيد حذف هذا الكوكيز؟" : "Delete this cookie?")) {
    try {
      const res = await fetch("/api/admin/cookies/delete", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminAuthToken}`
        },
        body: JSON.stringify({ id })
      });
      const data = await res.json();
      if (data.success) {
        showToast(data.message, "info");
        loadAdminInventory();
        loadPoolStatus();
      }
    } catch (e) {
      showToast("Delete failed", "error");
    }
  }
};
