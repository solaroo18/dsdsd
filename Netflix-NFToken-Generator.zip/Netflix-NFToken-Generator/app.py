import json
import os
import re
import urllib.parse
import hashlib
import hmac
from datetime import datetime
import io
import base64
import random
import uuid
import time
import secrets
from collections import defaultdict
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

from flask import Flask, render_template, request, jsonify, session, abort
import requests
from urllib3.exceptions import InsecureRequestWarning
import qrcode

requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

app = Flask(__name__, static_folder="static", template_folder="templates")

# Persistent secret key shared across all Gunicorn workers and restarts
def load_or_generate_secret_key():
    """Load or generate a persistent secret key for Flask sessions and HMAC signing."""
    env_key = os.environ.get("FLASK_SECRET_KEY")
    if env_key and len(env_key.strip()) >= 16:
        return env_key.strip()

    secret_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".flask_secret")
    try:
        if os.path.exists(secret_file):
            with open(secret_file, "r", encoding="utf-8") as f:
                key = f.read().strip()
                if len(key) >= 32:
                    return key
        new_key = secrets.token_hex(32)
        with open(secret_file, "w", encoding="utf-8") as f:
            f.write(new_key)
        try:
            os.chmod(secret_file, 0o600)
        except Exception:
            pass
        return new_key
    except Exception:
        return "netflix-token-gen-fallback-secret-2026-secure-key"

SECRET_KEY_VALUE = load_or_generate_secret_key()
app.secret_key = SECRET_KEY_VALUE
# Limit max body size to 2MB to prevent denial of service (DoS) memory exhaustion
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024
app.config["TEMPLATES_AUTO_RELOAD"] = True
# Secure session cookies
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("FLASK_ENV") == "production"

# Security Response Headers (OWASP Hardening)
@app.after_request
def add_security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data:; "
        "connect-src 'self'; "
        "frame-ancestors 'none'; "
        "base-uri 'self'; "
        "form-action 'self';"
    )
    # Remove server identification
    response.headers["Server"] = "Protected"
    # Prevent caching of sensitive API responses
    if request.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
    return response

INPUT_FILE = "input.txt"
HISTORY_FILE = "history.json"
POOL_FILE = "cookies_pool.json"
CONFIG_FILE = "admin_config.json"
DEVICE_LIMITS_FILE = "device_limits.json"

DAILY_DEVICE_LIMIT = 3

DEFAULT_ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "cuberwise18")
# Password is ONLY read from admin_config.json (hashed) or ADMIN_PASSWORD env var.
# Never hardcode plaintext passwords in source code.
DEFAULT_ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")
SERVER_START_TIME = datetime.now()

# Global request rate limiter (per IP across all endpoints)
GLOBAL_RATE_LIMITS = defaultdict(list)  # ip -> [timestamps]
GLOBAL_RATE_MAX = 120  # max requests per minute per IP
GLOBAL_RATE_WINDOW = 60  # seconds

# CSRF Token store
CSRF_TOKENS = {}  # token -> expiry timestamp
CSRF_TOKEN_TTL = 3600  # 1 hour

API_URL = "https://ios.prod.ftl.netflix.com/iosui/user/15.48"

QUERY_PARAMS = {
    "appVersion": "15.48.1",
    "config": '{"gamesInTrailersEnabled":"false","isTrailersEvidenceEnabled":"false","cdsMyListSortEnabled":"true","kidsBillboardEnabled":"true","addHorizontalBoxArtToVideoSummariesEnabled":"false","skOverlayTestEnabled":"false","homeFeedTestTVMovieListsEnabled":"false","baselineOnIpadEnabled":"true","trailersVideoIdLoggingFixEnabled":"true","postPlayPreviewsEnabled":"false","bypassContextualAssetsEnabled":"false","roarEnabled":"false","useSeason1AltLabelEnabled":"false","disableCDSSearchPaginationSectionKinds":["searchVideoCarousel"],"cdsSearchHorizontalPaginationEnabled":"true","searchPreQueryGamesEnabled":"true","kidsMyListEnabled":"true","billboardEnabled":"true","useCDSGalleryEnabled":"true","contentWarningEnabled":"true","videosInPopularGamesEnabled":"true","avifFormatEnabled":"false","sharksEnabled":"true"}',
    "device_type": "NFAPPL-02-",
    "esn": "NFAPPL-02-IPHONE8%3D1-PXA-02026U9VV5O8AUKEAEO8PUJETCGDD4PQRI9DEB3MDLEMD0EACM4CS78LMD334MN3MQ3NMJ8SU9O9MVGS6BJCURM1PH1MUTGDPF4S4200",
    "idiom": "phone",
    "iosVersion": "15.8.5",
    "isTablet": "false",
    "languages": "en-US",
    "locale": "en-US",
    "maxDeviceWidth": "375",
    "model": "saget",
    "modelType": "IPHONE8-1",
    "odpAware": "true",
    "path": '["account","token","default"]',
    "pathFormat": "graph",
    "pixelDensity": "2.0",
    "progressive": "false",
    "responseFormat": "json",
}

BASE_HEADERS = {
    "User-Agent": "Argo/15.48.1 (iPhone; iOS 15.8.5; Scale/2.00)",
    "x-netflix.request.attempt": "1",
    "x-netflix.request.client.user.guid": "A4CS633D7VCBPE2GPK2HL4EKOE",
    "x-netflix.context.profile-guid": "A4CS633D7VCBPE2GPK2HL4EKOE",
    "x-netflix.request.routing": '{"path":"/nq/mobile/nqios/~15.48.0/user","control_tag":"iosui_argo"}',
    "x-netflix.context.app-version": "15.48.1",
    "x-netflix.argo.translated": "true",
    "x-netflix.context.form-factor": "phone",
    "x-netflix.context.sdk-version": "2012.4",
    "x-netflix.client.appversion": "15.48.1",
    "x-netflix.context.max-device-width": "375",
    "x-netflix.context.ab-tests": "",
    "x-netflix.tracing.cl.useractionid": "4DC655F2-9C3C-4343-8229-CA1B003C3053",
    "x-netflix.client.type": "argo",
    "x-netflix.client.ftl.esn": "NFAPPL-02-IPHONE8=1-PXA-02026U9VV5O8AUKEAEO8PUJETCGDD4PQRI9DEB3MDLEMD0EACM4CS78LMD334MN3MQ3NMJ8SU9O9MVGS6BJCURM1PH1MUTGDPF4S4200",
    "x-netflix.context.locales": "en-US",
    "x-netflix.context.top-level-uuid": "90AFE39F-ADF1-4D8A-B33E-528730990FE3",
    "x-netflix.client.iosversion": "15.8.5",
    "accept-language": "en-US;q=1",
    "x-netflix.argo.abtests": "",
    "x-netflix.context.os-version": "15.8.5",
    "x-netflix.request.client.context": '{"appState":"foreground"}',
    "x-netflix.context.ui-flavor": "argo",
    "x-netflix.argo.nfnsm": "9",
    "x-netflix.context.pixel-density": "2.0",
    "x-netflix.request.toplevel.uuid": "90AFE39F-ADF1-4D8A-B33E-528730990FE3",
    "x-netflix.request.client.timezoneid": "Asia/Dhaka",
}

COOKIE_KEYS = ("NetflixId", "SecureNetflixId", "nfvdid", "OptanonConsent")
REQUIRED_COOKIE = "NetflixId"


# -------------------------------------------------------------
# Security & Rate Limiting Engine
# -------------------------------------------------------------
LOGIN_FAILURES = defaultdict(list)    # ip -> [timestamps]
IP_LOCKOUTS = {}                      # ip -> lockout_expiry_time
RATE_LIMITS = defaultdict(list)       # ip:endpoint -> [timestamps]
SESSIONS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "admin_sessions.json")
SESSION_TTL = 12 * 3600               # 12 hours session life
LAST_CLEANUP = time.time()
CLEANUP_INTERVAL = 300                # Clean up every 5 minutes


def load_admin_sessions():
    """Load active sessions from persistent JSON file, safely across processes."""
    if not os.path.exists(SESSIONS_FILE):
        return {}
    try:
        with open(SESSIONS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_admin_sessions(sessions):
    """Atomically save active sessions to persistent JSON file."""
    try:
        tmp_file = f"{SESSIONS_FILE}.tmp.{os.getpid()}"
        with open(tmp_file, "w", encoding="utf-8") as f:
            json.dump(sessions, f, indent=2, ensure_ascii=False)
        os.replace(tmp_file, SESSIONS_FILE)
        try:
            os.chmod(SESSIONS_FILE, 0o600)
        except Exception:
            pass
    except Exception:
        pass


def cleanup_expired_data():
    """Periodically purge expired entries from in-memory and persistent stores to prevent memory leaks."""
    global LAST_CLEANUP
    now = time.time()
    if now - LAST_CLEANUP < CLEANUP_INTERVAL:
        return
    LAST_CLEANUP = now

    # Clean expired lockouts
    expired_ips = [ip for ip, exp in IP_LOCKOUTS.items() if now > exp]
    for ip in expired_ips:
        IP_LOCKOUTS.pop(ip, None)
        LOGIN_FAILURES.pop(ip, None)

    # Clean expired admin sessions from file
    try:
        sessions = load_admin_sessions()
        if sessions:
            active = {k: v for k, v in sessions.items() if now < v.get("expires", 0)}
            if len(active) != len(sessions):
                save_admin_sessions(active)
    except Exception:
        pass

    # Clean expired CSRF tokens
    expired_csrf = [t for t, exp in CSRF_TOKENS.items() if now > exp]
    for t in expired_csrf:
        del CSRF_TOKENS[t]

    # Clean old rate limit entries
    stale_keys = [k for k, v in RATE_LIMITS.items() if not v or now - max(v) > 120]
    for k in stale_keys:
        del RATE_LIMITS[k]
    stale_global = [k for k, v in GLOBAL_RATE_LIMITS.items() if not v or now - max(v) > 120]
    for k in stale_global:
        del GLOBAL_RATE_LIMITS[k]


def get_client_ip():
    """Extract real client IP, supporting Cloudflare (CF-Connecting-IP), X-Real-IP, and X-Forwarded-For."""
    for header in ("CF-Connecting-IP", "X-Real-IP", "True-Client-IP"):
        val = request.headers.get(header)
        if val:
            ip = val.split(",")[0].strip()
            if re.match(r'^[\d\.]+$', ip) or re.match(r'^[\da-fA-F:]+$', ip):
                return ip
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        ip = forwarded.split(",")[0].strip()
        # Basic IP format validation
        if re.match(r'^[\d\.]+$', ip) or re.match(r'^[\da-fA-F:]+$', ip):
            return ip
    return request.remote_addr or "127.0.0.1"


def check_global_rate_limit(ip):
    """Global rate limiter: max GLOBAL_RATE_MAX requests per GLOBAL_RATE_WINDOW seconds per IP."""
    now = time.time()
    GLOBAL_RATE_LIMITS[ip] = [t for t in GLOBAL_RATE_LIMITS[ip] if now - t < GLOBAL_RATE_WINDOW]
    if len(GLOBAL_RATE_LIMITS[ip]) >= GLOBAL_RATE_MAX:
        return False
    GLOBAL_RATE_LIMITS[ip].append(now)
    return True


@app.before_request
def global_security_checks():
    """Run global security checks before every request."""
    cleanup_expired_data()

    # Block requests with suspiciously large headers (header injection prevention)
    total_header_size = sum(len(k) + len(v) for k, v in request.headers)
    if total_header_size > 16384:  # 16KB max headers
        abort(413)

    # Global rate limiting for API endpoints
    if request.path.startswith("/api/"):
        ip = get_client_ip()
        if not check_global_rate_limit(ip):
            return jsonify({
                "success": False,
                "error": "تم تجاوز الحد الأقصى للطلبات. يرجى الانتظار قليلاً."
            }), 429

    # Validate Content-Type for POST/PUT requests with body
    if request.method in ("POST", "PUT") and request.content_length and request.content_length > 0:
        content_type = request.content_type or ""
        if not any(ct in content_type for ct in ["application/json", "multipart/form-data", "application/x-www-form-urlencoded"]):
            if request.path.startswith("/api/"):
                return jsonify({"success": False, "error": "Invalid content type"}), 415


def check_login_lockout(ip):
    now = time.time()
    if ip in IP_LOCKOUTS:
        if now < IP_LOCKOUTS[ip]:
            remaining = int(IP_LOCKOUTS[ip] - now)
            return False, remaining
        else:
            del IP_LOCKOUTS[ip]
            LOGIN_FAILURES.pop(ip, None)
    return True, 0


def record_login_failure(ip):
    now = time.time()
    LOGIN_FAILURES[ip] = [t for t in LOGIN_FAILURES[ip] if now - t < 900]
    LOGIN_FAILURES[ip].append(now)
    if len(LOGIN_FAILURES[ip]) >= 5:
        IP_LOCKOUTS[ip] = now + 900  # Lock out for 15 minutes
        return True
    return False


def record_login_success(ip):
    LOGIN_FAILURES.pop(ip, None)
    IP_LOCKOUTS.pop(ip, None)


def check_rate_limit(ip, endpoint, max_requests=25, window=60):
    now = time.time()
    key = f"{ip}:{endpoint}"
    RATE_LIMITS[key] = [t for t in RATE_LIMITS[key] if now - t < window]
    if len(RATE_LIMITS[key]) >= max_requests:
        return False
    RATE_LIMITS[key].append(now)
    return True


def generate_csrf_token():
    """Generate a CSRF token for forms and sensitive actions."""
    token = secrets.token_hex(32)
    CSRF_TOKENS[token] = time.time() + CSRF_TOKEN_TTL
    return token


def validate_csrf_token(token):
    """Validate and consume a CSRF token."""
    if not token:
        return False
    expiry = CSRF_TOKENS.pop(token, None)
    if expiry is None:
        return False
    return time.time() < expiry


def sanitize_input(text, max_length=10000):
    """Sanitize and truncate user input to prevent injection and DoS."""
    if not isinstance(text, str):
        return ""
    # Truncate to max length
    text = text[:max_length]
    # Remove null bytes
    text = text.replace("\x00", "")
    return text


# -------------------------------------------------------------
# Configuration & Admin Helpers
# -------------------------------------------------------------
def get_admin_config():
    cfg = {"username": DEFAULT_ADMIN_USERNAME, "password_hash": None}

    # Primary source: admin_config.json file (always preferred)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            cfg["username"] = data.get("username", DEFAULT_ADMIN_USERNAME)
            if "password_hash" in data:
                cfg["password_hash"] = data["password_hash"]
            elif "password" in data:
                # Auto-hash plaintext passwords found in config and rewrite securely
                new_hash = generate_password_hash(data["password"])
                cfg["password_hash"] = new_hash
                with open(CONFIG_FILE, "w", encoding="utf-8") as fw:
                    json.dump({"username": cfg["username"], "password_hash": new_hash}, fw, indent=2)
        except Exception:
            pass

    # Fallback: environment variable (for initial setup only)
    if not cfg["password_hash"] and DEFAULT_ADMIN_PASSWORD:
        cfg["password_hash"] = generate_password_hash(DEFAULT_ADMIN_PASSWORD)

    return cfg


def get_admin_username():
    return get_admin_config().get("username", DEFAULT_ADMIN_USERNAME)


def check_admin_password(provided_password):
    if not provided_password:
        return False
    config = get_admin_config()
    stored_hash = config.get("password_hash")
    if not stored_hash:
        return False
    return check_password_hash(stored_hash, provided_password)


def set_admin_credentials(new_user, new_pass):
    try:
        hashed = generate_password_hash(new_pass)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump({"username": new_user, "password_hash": hashed}, f, indent=2)
        save_admin_sessions({})  # Invalidate all existing admin sessions upon credential change
        return True
    except Exception:
        return False


def sign_session_payload(payload_str):
    """Compute HMAC-SHA256 signature for session payload using SECRET_KEY_VALUE."""
    return hmac.new(SECRET_KEY_VALUE.encode("utf-8"), payload_str.encode("utf-8"), hashlib.sha256).hexdigest()


def create_admin_session(username, client_ip):
    """Create a tamper-proof cryptographically signed token and record in persistent store."""
    sessions = load_admin_sessions()
    now = time.time()

    # Clean up expired sessions from persistent store
    active = {k: v for k, v in sessions.items() if now < v.get("expires", 0)}

    # Cap total sessions to 50
    if len(active) >= 50:
        sorted_sessions = sorted(active.items(), key=lambda x: x[1].get("created_at", 0))
        for old_token, _ in sorted_sessions[:25]:
            active.pop(old_token, None)

    sid = secrets.token_hex(16)
    expires = now + SESSION_TTL

    payload_dict = {
        "u": username,
        "exp": int(expires),
        "sid": sid,
        "cat": int(now)
    }
    raw_payload = json.dumps(payload_dict, separators=(',', ':'))
    b64_payload = base64.urlsafe_b64encode(raw_payload.encode('utf-8')).decode('utf-8').rstrip('=')
    signature = sign_session_payload(b64_payload)
    token = f"adm_{b64_payload}.{signature}"

    active[token] = {
        "username": username,
        "expires": expires,
        "ip": client_ip,
        "created_at": now,
        "last_seen": now
    }
    save_admin_sessions(active)
    return token


def verify_admin_token(token):
    """
    Verify admin token:
    1. Cryptographic HMAC validation (instant, uniform across all Gunicorn workers).
    2. Expiration validation.
    3. Persistent session file check (to ensure token was not revoked via logout/password change).
    Crucially: NEVER destroys session on client IP change (dynamic ISP, 4G/5G mobile, or CDN).
    """
    if not token or not isinstance(token, str):
        return False

    token = token.strip()
    now = time.time()

    # 1. Cryptographically signed token format: adm_<base64_payload>.<signature>
    if token.startswith("adm_") and "." in token:
        try:
            body = token[4:]  # strip 'adm_'
            b64_payload, signature = body.split(".", 1)
            expected_sig = sign_session_payload(b64_payload)
            if not secrets.compare_digest(signature, expected_sig):
                return False

            padding = '=' * (-len(b64_payload) % 4)
            raw_payload = base64.urlsafe_b64decode((b64_payload + padding).encode('utf-8')).decode('utf-8')
            payload = json.loads(raw_payload)

            # Check expiration
            if now > payload.get("exp", 0):
                return False

            # Check revocation in persistent sessions
            sessions = load_admin_sessions()
            if token not in sessions:
                # Token was revoked (e.g. logout or password change)
                return False

            sess_info = sessions[token]
            if now > sess_info.get("expires", 0):
                return False

            # Periodically update last_seen without blocking
            if now - sess_info.get("last_seen", 0) > 300:
                sess_info["last_seen"] = now
                sess_info["last_ip"] = get_client_ip()
                save_admin_sessions(sessions)
            return True
        except Exception:
            return False

    # 2. Fallback check in persistent sessions file (for legacy or direct tokens)
    sessions = load_admin_sessions()
    session_info = sessions.get(token)
    if not session_info:
        return False
    if now > session_info.get("expires", 0):
        return False
    return True


def require_admin(f):
    """Decorator to enforce admin authentication on endpoints."""
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "").replace("Bearer ", "")
        if not verify_admin_token(auth):
            return jsonify({"success": False, "error": "غير مصرح لك بالوصول"}), 403
        return f(*args, **kwargs)
    return decorated


# -------------------------------------------------------------
# Cookie Pool Management
# -------------------------------------------------------------
def load_pool():
    if not os.path.exists(POOL_FILE):
        # Auto seed from input.txt if it exists
        initial_pool = []
        if os.path.exists(INPUT_FILE):
            try:
                with open(INPUT_FILE, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                if content and "NetflixId" in content:
                    cd = extract_cookie_dict(content)
                    if "NetflixId" in cd:
                        initial_pool.append({
                            "id": "cookie_initial",
                            "name": "حساب افتراضي 1",
                            "raw": content,
                            "netflix_id_preview": cd["NetflixId"][:15] + "...",
                            "format": detect_cookie_format(content),
                            "status": "active",
                            "usage_count": 0,
                            "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "last_used": None,
                        })
            except Exception:
                pass
        save_pool(initial_pool)
        return initial_pool

    try:
        with open(POOL_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def save_pool(pool):
    try:
        with open(POOL_FILE, "w", encoding="utf-8") as f:
            json.dump(pool, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def get_active_cookies_count():
    pool = load_pool()
    return sum(1 for c in pool if c.get("status") == "active")


# -------------------------------------------------------------
# Cookie Parser Utilities
# -------------------------------------------------------------
def parse_netscape_cookie_line(line):
    parts = line.strip().split("\t")
    if len(parts) >= 7:
        return {parts[5]: parts[6]}
    return {}


def _decode_cookie_value(value):
    if isinstance(value, str) and "%" in value:
        try:
            return urllib.parse.unquote(value)
        except Exception:
            return value
    return value


def extract_cookie_dict(text):
    if not text:
        return {}
    cookie_dict = {}

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        cookie_dict.update(parse_netscape_cookie_line(line))

    try:
        data = json.loads(text)
    except Exception:
        data = None

    if isinstance(data, list):
        for cookie in data:
            name = cookie.get("name")
            value = cookie.get("value")
            if name in COOKIE_KEYS and isinstance(value, str):
                cookie_dict[name] = _decode_cookie_value(value)
    elif isinstance(data, dict):
        if any(key in data for key in COOKIE_KEYS):
            for key in COOKIE_KEYS:
                value = data.get(key)
                if isinstance(value, str):
                    cookie_dict[key] = _decode_cookie_value(value)
        elif isinstance(data.get("cookies"), list):
            for cookie in data["cookies"]:
                name = cookie.get("name")
                value = cookie.get("value")
                if name in COOKIE_KEYS and isinstance(value, str):
                    cookie_dict[name] = _decode_cookie_value(value)

    for key in COOKIE_KEYS:
        if key in cookie_dict:
            continue
        match = re.search(rf"(?<!\w){re.escape(key)}=([^;,\s]+)", text)
        if match:
            cookie_dict[key] = _decode_cookie_value(match.group(1))

    return cookie_dict


def detect_cookie_format(text):
    if not text or not text.strip():
        return "empty"
    stripped = text.strip()
    if (stripped.startswith("{") and stripped.endswith("}")) or (stripped.startswith("[") and stripped.endswith("]")):
        return "json"
    if "\t" in stripped:
        return "netscape"
    if "NetflixId=" in stripped:
        return "raw"
    return "unknown"


def generate_qr_base64(data_string):
    try:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=8,
            border=2,
        )
        qr.add_data(data_string)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#E50914", back_color="#0D0D11")
        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        buffer.seek(0)
        return "data:image/png;base64," + base64.b64encode(buffer.getvalue()).decode("utf-8")
    except Exception:
        return None


def fetch_nftoken_api(cookie_dict):
    netflix_id = cookie_dict.get(REQUIRED_COOKIE)
    if not netflix_id:
        return None, None, "Missing required cookie: NetflixId (الكوكيز لا يحتوي على NetflixId)"

    headers = dict(BASE_HEADERS)
    cookie_parts = [f"NetflixId={netflix_id}"]
    if "SecureNetflixId" in cookie_dict:
        cookie_parts.append(f"SecureNetflixId={cookie_dict['SecureNetflixId']}")
    if "nfvdid" in cookie_dict:
        cookie_parts.append(f"nfvdid={cookie_dict['nfvdid']}")
    headers["Cookie"] = "; ".join(cookie_parts)

    try:
        response = requests.get(
            API_URL,
            params=QUERY_PARAMS,
            headers=headers,
            timeout=25,
            verify=False,
        )
    except requests.exceptions.Timeout:
        return None, None, "Connection timed out connecting to Netflix API (انتهت مهلة الاتصال بخوادم نتفلكس)"
    except requests.exceptions.RequestException as e:
        return None, None, f"Network request error: {str(e)}"

    if response.status_code != 200:
        return None, None, f"Netflix server returned status {response.status_code}: {response.text[:200]}"

    try:
        data = response.json()
    except Exception:
        return None, None, "Invalid JSON response from Netflix API"

    token_data = (
        (((data.get("value") or {}).get("account") or {}).get("token") or {}).get("default")
        or {}
    )
    token = token_data.get("token")
    expires = token_data.get("expires")

    if not token:
        inner_error = data.get("error") or data.get("message")
        if inner_error:
            return None, None, f"Netflix response error: {inner_error}"
        return None, None, "No token found in response. The cookie might be expired or invalid. (لم يتم العثور على توكن، قد يكون الكوكيز منتهي الصلاحية أو غير صالح)"

    if isinstance(expires, int) and len(str(expires)) == 13:
        expires //= 1000

    return token, expires, None


def load_history():
    if not os.path.exists(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def save_history_item(item):
    history = load_history()
    history.insert(0, item)
    history = history[:50]
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


# -------------------------------------------------------------
# Device Quota Limiter (3 Activations Per Day Per Device)
# -------------------------------------------------------------
def load_device_limits():
    if not os.path.exists(DEVICE_LIMITS_FILE):
        return {}
    try:
        with open(DEVICE_LIMITS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_device_limits(data):
    try:
        with open(DEVICE_LIMITS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception:
        pass


def get_device_identifier():
    req_data = request.get_json(silent=True) or {}
    dev_header = (
        request.headers.get("X-Device-Id")
        or req_data.get("device_id")
        or request.cookies.get("device_id")
    )
    client_ip = get_client_ip()

    if dev_header and isinstance(dev_header, str) and 8 <= len(dev_header) <= 64:
        # Strictly sanitize device ID to prevent injection
        clean_dev = re.sub(r'[^a-zA-Z0-9_\-]', '', dev_header)[:64]
        if clean_dev and len(clean_dev) >= 8:
            return clean_dev

    ua = request.headers.get("User-Agent", "unknown")[:256]  # Truncate UA
    fp = f"ip_{uuid.uuid5(uuid.NAMESPACE_DNS, f'{client_ip}_{ua}').hex[:16]}"
    return fp


def check_device_quota(device_id):
    today = datetime.now().strftime("%Y-%m-%d")
    limits = load_device_limits()
    record = limits.get(device_id, {})

    rec_date = record.get("date")
    if rec_date != today:
        current_count = 0
    else:
        current_count = record.get("count", 0)

    remaining = max(0, DAILY_DEVICE_LIMIT - current_count)
    allowed = current_count < DAILY_DEVICE_LIMIT
    return allowed, current_count, remaining, today


def increment_device_quota(device_id, action_type="activation"):
    today = datetime.now().strftime("%Y-%m-%d")
    limits = load_device_limits()
    record = limits.get(device_id, {})

    rec_date = record.get("date")
    if rec_date != today:
        current_count = 1
        history = []
    else:
        current_count = record.get("count", 0) + 1
        history = record.get("history", [])

    history.append({
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "type": action_type,
        "ip": get_client_ip()
    })

    limits[device_id] = {
        "date": today,
        "count": current_count,
        "last_active": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "history": history[-10:]
    }
    save_device_limits(limits)
    remaining = max(0, DAILY_DEVICE_LIMIT - current_count)
    return current_count, remaining


# -------------------------------------------------------------
# Routes
# -------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/admina")
@app.route("/admin")
def admin_page():
    return render_template("admin.html")


@app.route("/api/device/quota", methods=["GET"])
def device_quota_status():
    auth = request.headers.get("Authorization", "").replace("Bearer ", "")
    if verify_admin_token(auth):
        return jsonify({
            "success": True,
            "device_id": "admin",
            "today": datetime.now().strftime("%Y-%m-%d"),
            "limit": DAILY_DEVICE_LIMIT,
            "used": 0,
            "remaining": DAILY_DEVICE_LIMIT,
            "can_activate": True,
            "is_admin": True
        })

    dev_id = get_device_identifier()
    allowed, used, remaining, today = check_device_quota(dev_id)
    return jsonify({
        "success": True,
        "device_id": dev_id,
        "today": today,
        "limit": DAILY_DEVICE_LIMIT,
        "used": used,
        "remaining": remaining,
        "can_activate": allowed,
        "is_admin": False
    })


@app.route("/api/pool/status", methods=["GET"])
def pool_status():
    pool = load_pool()
    active_count = sum(1 for c in pool if c.get("status") == "active")
    total_count = len(pool)
    return jsonify({
        "success": True,
        "active_count": active_count,
        "total_count": total_count,
        "has_cookies": active_count > 0,
    })


@app.route("/api/generate-from-pool", methods=["POST"])
def generate_from_pool():
    auth = request.headers.get("Authorization", "").replace("Bearer ", "")
    is_admin = verify_admin_token(auth)
    dev_id = get_device_identifier()

    # Check device daily limit (3 activations per day)
    if not is_admin:
        allowed, used, remaining, _ = check_device_quota(dev_id)
        if not allowed:
            return jsonify({
                "success": False,
                "error": "لقد استنفدت الحد اليومي المسموح به (3 تفعيلات لكل جهاز يومياً). يرجى العودة غداً!",
                "limit_reached": True,
                "limit": DAILY_DEVICE_LIMIT,
                "used": used,
                "remaining": 0
            }), 429

    ip = get_client_ip()
    if not check_rate_limit(ip, "/api/generate-from-pool", max_requests=25, window=60):
        return jsonify({
            "success": False,
            "error": "تم تجاوز معدل الطلبات المسموح به لحماية الموقع. يرجى الانتظار دقيقة واحدة."
        }), 429

    pool = load_pool()
    active_cookies = [c for c in pool if c.get("status") == "active"]

    if not active_cookies:
        return jsonify({
            "success": False,
            "error": "عذراً، لا يوجد كوكيز متوفرة حالياً في النظام! يرجى إبلاغ المسؤول لإضافة كوكيز جديدة.",
            "details": "Cookie pool is empty or all cookies are inactive"
        }), 400

    # Try random selection with fallback up to 3 attempts
    random.shuffle(active_cookies)
    last_error = None

    for candidate in active_cookies:
        raw_cookie = candidate.get("raw", "")
        cookie_dict = extract_cookie_dict(raw_cookie)
        if not cookie_dict or REQUIRED_COOKIE not in cookie_dict:
            candidate["status"] = "invalid"
            save_pool(pool)
            continue

        token, expires, err = fetch_nftoken_api(cookie_dict)
        if err or not token:
            last_error = err
            # If expired, mark in pool
            if "expired" in str(err).lower() or "no token found" in str(err).lower():
                candidate["status"] = "expired"
                save_pool(pool)
            continue

        # SUCCESS!
        candidate["usage_count"] = candidate.get("usage_count", 0) + 1
        candidate["last_used"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        candidate["last_status"] = "active"
        save_pool(pool)

        encoded_token = urllib.parse.quote(token, safe="")
        login_url = f"https://www.netflix.com/youraccount?nftoken={encoded_token}"
        browse_url = f"https://www.netflix.com/browse?nftoken={encoded_token}"
        tv_activation_url = f"https://www.netflix.com/tv8?nftoken={encoded_token}"
        unsupported_url = f"https://www.netflix.com/unsupported?nftoken={encoded_token}"
        direct_tv_url = "https://www.netflix.com/tv8"

        formatted_expires = "Unknown"
        if isinstance(expires, (int, float)):
            try:
                formatted_expires = datetime.fromtimestamp(expires).strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                formatted_expires = str(expires)

        login_qr = generate_qr_base64(login_url)
        tv_qr = generate_qr_base64(tv_activation_url)
        unsupported_qr = generate_qr_base64(unsupported_url)

        res_payload = {
            "success": True,
            "token": token,
            "login_url": login_url,
            "browse_url": browse_url,
            "tv_activation_url": tv_activation_url,
            "unsupported_url": unsupported_url,
            "direct_tv_url": direct_tv_url,
            "expires_timestamp": expires,
            "expires_formatted": formatted_expires,
            "login_qr": login_qr,
            "tv_qr": tv_qr,
            "unsupported_qr": unsupported_qr,
            "used_cookie_name": candidate.get("name", "حساب من المستودع"),
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

        save_history_item({
            "token_preview": token[:18] + "..." if len(token) > 18 else token,
            "full_token": token,
            "login_url": login_url,
            "tv_activation_url": tv_activation_url,
            "expires_formatted": formatted_expires,
            "account_name": candidate.get("name", "Pool Cookie"),
            "created_at": res_payload["created_at"],
        })

        # Increment quota count for this device
        if not is_admin:
            used_now, rem_now = increment_device_quota(dev_id, "pool_generation")
            res_payload["device_quota"] = {
                "limit": DAILY_DEVICE_LIMIT,
                "used": used_now,
                "remaining": rem_now
            }

        return jsonify(res_payload)

    return jsonify({
        "success": False,
        "error": "تعذر توليد التوكن من الكوكيز المتوفرة حالياً (قد تكون منتهية الصلاحية). يرجى المحاولة لاحقاً أو إبلاغ المسؤول.",
        "details": last_error or "All tested cookies failed"
    }), 400


@app.route("/api/generate", methods=["POST"])
def generate_custom_token():
    auth = request.headers.get("Authorization", "").replace("Bearer ", "")
    is_admin = verify_admin_token(auth)
    dev_id = get_device_identifier()

    data = request.get_json(silent=True) or {}
    raw_cookie = sanitize_input(data.get("cookie", ""), max_length=50000).strip()

    if not raw_cookie:
        return generate_from_pool()

    if not is_admin:
        allowed, used, remaining, _ = check_device_quota(dev_id)
        if not allowed:
            return jsonify({
                "success": False,
                "error": "لقد استنفدت الحد اليومي المسموح به (3 تفعيلات لكل جهاز يومياً). يرجى العودة غداً!",
                "limit_reached": True,
                "limit": DAILY_DEVICE_LIMIT,
                "used": used,
                "remaining": 0
            }), 429

    cookie_dict = extract_cookie_dict(raw_cookie)
    if not cookie_dict or REQUIRED_COOKIE not in cookie_dict:
        return jsonify({
            "success": False,
            "error": "لم يتم العثور على NetflixId في الكوكيز المدخل. تأكد من نسخ الكوكيز بشكل صحيح."
        }), 400

    token, expires, err = fetch_nftoken_api(cookie_dict)
    if err or not token:
        return jsonify({
            "success": False,
            "error": err or "فشل في توليد التوكن",
            "details": err
        }), 400

    encoded_token = urllib.parse.quote(token, safe="")
    login_url = f"https://www.netflix.com/youraccount?nftoken={encoded_token}"
    browse_url = f"https://www.netflix.com/browse?nftoken={encoded_token}"
    tv_activation_url = f"https://www.netflix.com/tv8?nftoken={encoded_token}"
    unsupported_url = f"https://www.netflix.com/unsupported?nftoken={encoded_token}"
    direct_tv_url = "https://www.netflix.com/tv8"

    formatted_expires = "Unknown"
    if isinstance(expires, (int, float)):
        try:
            formatted_expires = datetime.fromtimestamp(expires).strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            formatted_expires = str(expires)

    login_qr = generate_qr_base64(login_url)
    tv_qr = generate_qr_base64(tv_activation_url)
    unsupported_qr = generate_qr_base64(unsupported_url)

    result_payload = {
        "success": True,
        "token": token,
        "login_url": login_url,
        "browse_url": browse_url,
        "tv_activation_url": tv_activation_url,
        "unsupported_url": unsupported_url,
        "direct_tv_url": direct_tv_url,
        "expires_timestamp": expires,
        "expires_formatted": formatted_expires,
        "login_qr": login_qr,
        "tv_qr": tv_qr,
        "unsupported_qr": unsupported_qr,
        "cookie_info": {
            "format": detect_cookie_format(raw_cookie),
            "keys": list(cookie_dict.keys()),
        },
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }

    save_history_item({
        "token_preview": token[:18] + "..." if len(token) > 18 else token,
        "full_token": token,
        "login_url": login_url,
        "tv_activation_url": tv_activation_url,
        "expires_formatted": formatted_expires,
        "account_name": "كوكيز مخصص",
        "created_at": result_payload["created_at"],
    })

    if not is_admin:
        used_now, rem_now = increment_device_quota(dev_id, "custom_generation")
        result_payload["device_quota"] = {
            "limit": DAILY_DEVICE_LIMIT,
            "used": used_now,
            "remaining": rem_now
        }

    return jsonify(result_payload)


@app.route("/api/activate-tv", methods=["POST"])
def activate_tv():
    auth = request.headers.get("Authorization", "").replace("Bearer ", "")
    is_admin = verify_admin_token(auth)
    dev_id = get_device_identifier()

    ip = get_client_ip()
    if not check_rate_limit(ip, "/api/activate-tv", max_requests=25, window=60):
        return jsonify({
            "success": False,
            "error": "تم تجاوز معدل الطلبات المسموح به لحماية الموقع. يرجى الانتظار دقيقة واحدة."
        }), 429

    data = request.get_json(silent=True) or {}
    tv_code = data.get("code", "").strip().replace("-", "").replace(" ", "").upper()
    token = data.get("token", "").strip()

    # If user activates TV directly without having generated a token, check daily limit
    if not is_admin and not token:
        allowed, used, remaining, _ = check_device_quota(dev_id)
        if not allowed:
            return jsonify({
                "success": False,
                "error": "لقد استنفدت الحد اليومي المسموح به (3 تفعيلات لكل جهاز يومياً). يرجى العودة غداً!",
                "limit_reached": True,
                "limit": DAILY_DEVICE_LIMIT,
                "used": used,
                "remaining": 0
            }), 429

    if not tv_code or not re.match(r'^[A-Za-z0-9]{8}$', tv_code):
        return jsonify({
            "success": False,
            "error": "يرجى إدخال رمز تفعيل صالح مكون من 8 خانات أرقام وحروف فقط"
        }), 400

    formatted_code = f"{tv_code[:4]}-{tv_code[4:]}" if len(tv_code) >= 8 else tv_code

    if token:
        encoded_token = urllib.parse.quote(token, safe="")
        auto_activate_url = f"https://www.netflix.com/tv8?nftoken={encoded_token}"
        direct_tv_link = "https://www.netflix.com/tv8"
    else:
        auto_activate_url = "https://www.netflix.com/tv8"
        direct_tv_link = "https://www.netflix.com/tv8"

    tv_qr = generate_qr_base64(auto_activate_url)

    if not is_admin and not token:
        increment_device_quota(dev_id, action_type="tv_direct_activation")

    return jsonify({
        "success": True,
        "code": formatted_code,
        "auto_activate_url": auto_activate_url,
        "direct_tv_link": direct_tv_link,
        "tv_qr": tv_qr,
        "message": "قم بفتح رابط التفعيل وسيقوم بتسجيل الدخول مباشرة على حسابك وتوجيهك لصفحة إدخال الرمز",
    })


@app.route("/api/qr", methods=["GET"])
def get_qr_image():
    ip = get_client_ip()
    if not check_rate_limit(ip, "/api/qr", max_requests=30, window=60):
        return jsonify({"success": False, "error": "Rate limit exceeded"}), 429

    data = sanitize_input(request.args.get("data", ""), max_length=2000).strip()
    if not data:
        return jsonify({"success": False, "error": "Missing data parameter"}), 400
    # Only allow QR generation for known safe URL patterns
    if not data.startswith("https://www.netflix.com/") and not data.startswith("https://netflix.com/"):
        return jsonify({"success": False, "error": "Invalid data for QR generation"}), 400
    try:
        qr_img = generate_qr_base64(data)
        return jsonify({"success": True, "qr": qr_img})
    except Exception:
        return jsonify({"success": False, "error": "QR generation failed"}), 500


# -------------------------------------------------------------
# Admin API Endpoints
# -------------------------------------------------------------
@app.route("/api/admin/login", methods=["POST"])
def admin_login():
    ip = get_client_ip()
    allowed, remaining = check_login_lockout(ip)
    if not allowed:
        return jsonify({
            "success": False,
            "error": f"تم حظر المحاولات مؤقتاً لحماية الموقع بسبب تكرار الخطأ. يرجى الانتظار {remaining // 60 + 1} دقيقة."
        }), 429

    data = request.get_json(silent=True) or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()

    if not username or not password:
        return jsonify({"success": False, "error": "يرجى إدخال اسم المستخدم وكلمة المرور"}), 400

    valid_user = get_admin_username()
    # Constant-time comparison for username against timing attacks
    user_match = secrets.compare_digest(username.lower(), valid_user.lower())
    pass_match = check_admin_password(password)

    if user_match and pass_match:
        record_login_success(ip)
        token = create_admin_session(valid_user, ip)
        return jsonify({
            "success": True,
            "token": token,
            "username": valid_user,
            "message": "تم تسجيل دخول المشرف بنجاح"
        })

    locked = record_login_failure(ip)
    if locked:
        return jsonify({
            "success": False,
            "error": "تم تجاوز الحد الأقصى للمحاولات الخاطئة (5 محاولات). تم حظر الـ IP لمدة 15 دقيقة لحماية اللوحة."
        }), 429

    return jsonify({
        "success": False,
        "error": "اسم المستخدم أو كلمة المرور غير صحيحة"
    }), 401


@app.route("/api/admin/logout", methods=["POST"])
def admin_logout():
    auth = request.headers.get("Authorization", "").replace("Bearer ", "").strip()
    if auth:
        sessions = load_admin_sessions()
        if auth in sessions:
            sessions.pop(auth, None)
            save_admin_sessions(sessions)
    return jsonify({"success": True, "message": "تم إنهاء الجلسة بنجاح"})


@app.route("/api/admin/cookies", methods=["GET"])
@require_admin
def admin_get_cookies():
    pool = load_pool()
    # return sanitized copy — never expose raw cookie data in list view
    safe_pool = []
    for c in pool:
        safe_copy = {
            "id": c.get("id"),
            "name": c.get("name"),
            "netflix_id_preview": c.get("netflix_id_preview"),
            "format": c.get("format"),
            "status": c.get("status"),
            "usage_count": c.get("usage_count", 0),
            "added_at": c.get("added_at"),
            "last_used": c.get("last_used"),
            "last_status": c.get("last_status"),
            "raw_length": len(c.get("raw", "")),
        }
        safe_pool.append(safe_copy)
    return jsonify({"success": True, "cookies": safe_pool, "total": len(pool)})


@app.route("/api/admin/cookies/add", methods=["POST"])
@require_admin
def admin_add_cookies():

    data = request.get_json(silent=True) or {}
    raw_input = sanitize_input(data.get("cookies_text", ""), max_length=100000).strip()
    base_name = sanitize_input(data.get("name", ""), max_length=100).strip() or "حساب نتفلكس"

    if not raw_input:
        return jsonify({"success": False, "error": "يرجى إدخال نص الكوكيز"}), 400

    pool = load_pool()

    # Split by delimiter if user pasted multiple cookies (e.g., separated by '---' or lines of JSON)
    chunks = re.split(r"\n\s*---\s*\n|\n\s*===\s*\n", raw_input)
    if len(chunks) == 1 and raw_input.startswith("[") and raw_input.endswith("]"):
        try:
            parsed_json = json.loads(raw_input)
            if isinstance(parsed_json, list) and len(parsed_json) > 0 and isinstance(parsed_json[0], list):
                chunks = [json.dumps(sub) for sub in parsed_json]
        except Exception:
            pass

    added_count = 0
    errors = []

    for idx, chunk in enumerate(chunks, 1):
        clean_chunk = chunk.strip()
        if not clean_chunk:
            continue
        cd = extract_cookie_dict(clean_chunk)
        if not cd or REQUIRED_COOKIE not in cd:
            errors.append(f"القطعة #{idx}: لم يتم العثور على NetflixId صالح.")
            continue

        item_name = f"{base_name} #{len(pool) + 1}" if len(chunks) > 1 else base_name
        new_item = {
            "id": f"ck_{uuid.uuid4().hex[:8]}",
            "name": item_name,
            "raw": clean_chunk,
            "netflix_id_preview": cd["NetflixId"][:15] + "...",
            "format": detect_cookie_format(clean_chunk),
            "status": "active",
            "usage_count": 0,
            "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "last_used": None,
            "last_status": "new",
        }
        pool.append(new_item)
        added_count += 1

    save_pool(pool)

    return jsonify({
        "success": added_count > 0,
        "added_count": added_count,
        "errors": errors,
        "message": f"تمت إضافة {added_count} كوكيز بنجاح إلى المستودع"
    })


@app.route("/api/admin/cookies/delete", methods=["POST"])
@require_admin
def admin_delete_cookie():

    data = request.get_json(silent=True) or {}
    cookie_id = data.get("id")

    pool = load_pool()
    new_pool = [c for c in pool if c.get("id") != cookie_id]
    save_pool(new_pool)

    return jsonify({"success": True, "message": "تم حذف الكوكيز بنجاح"})


@app.route("/api/admin/cookies/toggle", methods=["POST"])
@require_admin
def admin_toggle_cookie():

    data = request.get_json(silent=True) or {}
    cookie_id = data.get("id")

    pool = load_pool()
    for c in pool:
        if c.get("id") == cookie_id:
            c["status"] = "inactive" if c.get("status") == "active" else "active"
            save_pool(pool)
            return jsonify({"success": True, "status": c["status"]})

    return jsonify({"success": False, "error": "الكوكيز غير موجود"}), 404


@app.route("/api/admin/cookies/test", methods=["POST"])
@require_admin
def admin_test_cookie():

    data = request.get_json(silent=True) or {}
    cookie_id = data.get("id")

    pool = load_pool()
    target = next((c for c in pool if c.get("id") == cookie_id), None)
    if not target:
        return jsonify({"success": False, "error": "الكوكيز غير موجود"}), 404

    cd = extract_cookie_dict(target.get("raw", ""))
    token, expires, err = fetch_nftoken_api(cd)

    if err or not token:
        target["last_status"] = "error"
        if "expired" in str(err).lower() or "no token found" in str(err).lower():
            target["status"] = "expired"
        save_pool(pool)
        return jsonify({"success": False, "error": err or "فحص فاشل"})

    target["last_status"] = "valid"
    target["status"] = "active"
    save_pool(pool)
    return jsonify({
        "success": True,
        "token_preview": token[:15] + "...",
        "expires": expires,
        "message": "الكوكيز صالح ويعمل بنجاح!"
    })


@app.route("/api/admin/cookies/clear", methods=["POST"])
@require_admin
def admin_clear_all():
    save_pool([])
    return jsonify({"success": True, "message": "تم مسح جميع الكوكيز من المستودع"})


@app.route("/api/admin/cookies/import-input", methods=["POST"])
@require_admin
def admin_import_from_input():

    if not os.path.exists(INPUT_FILE):
        return jsonify({"success": False, "error": "ملف input.txt غير موجود"}), 404

    try:
        with open(INPUT_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

    cd = extract_cookie_dict(content)
    if not cd or REQUIRED_COOKIE not in cd:
        return jsonify({"success": False, "error": "محتوى input.txt لا يحتوي على NetflixId صالح"}), 400

    pool = load_pool()
    new_item = {
        "id": f"ck_{uuid.uuid4().hex[:8]}",
        "name": f"كوكيز من input.txt (#{len(pool) + 1})",
        "raw": content,
        "netflix_id_preview": cd["NetflixId"][:15] + "...",
        "format": detect_cookie_format(content),
        "status": "active",
        "usage_count": 0,
        "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "last_used": None,
        "last_status": "new",
    }
    pool.append(new_item)
    save_pool(pool)

    return jsonify({"success": True, "message": "تم استيراد الكوكيز من input.txt بنجاح"})


@app.route("/api/admin/change-password", methods=["POST"])
@require_admin
def admin_change_password():

    data = request.get_json(silent=True) or {}
    new_pass = sanitize_input(data.get("new_password", ""), max_length=128).strip()
    if not new_pass or len(new_pass) < 8:
        return jsonify({"success": False, "error": "يجب أن تكون كلمة المرور 8 أحرف على الأقل"}), 400

    if set_admin_credentials(get_admin_username(), new_pass):
        ip = get_client_ip()
        new_token = create_admin_session(get_admin_username(), ip)
        return jsonify({"success": True, "token": new_token, "message": "تم تحديث كلمة المرور بنجاح"})
    return jsonify({"success": False, "error": "تعذر حفظ كلمة المرور"}), 500


@app.route("/api/admin/change-credentials", methods=["POST"])
@require_admin
def admin_change_credentials():

    data = request.get_json(silent=True) or {}
    new_user = sanitize_input(data.get("new_username", ""), max_length=64).strip() or get_admin_username()
    new_pass = sanitize_input(data.get("new_password", ""), max_length=128).strip()

    # Validate username: alphanumeric + underscore only
    if not re.match(r'^[a-zA-Z0-9_]+$', new_user) or len(new_user) < 3:
        return jsonify({"success": False, "error": "اسم المستخدم يجب أن يكون 3 أحرف على الأقل ويحتوي على أحرف وأرقام فقط"}), 400
    if not new_pass or len(new_pass) < 8:
        return jsonify({"success": False, "error": "كلمة المرور يجب أن تكون 8 أحرف على الأقل"}), 400

    if set_admin_credentials(new_user, new_pass):
        ip = get_client_ip()
        new_token = create_admin_session(new_user, ip)
        return jsonify({
            "success": True,
            "token": new_token,
            "username": new_user,
            "message": "تم تحديث بيانات تسجيل الدخول بنجاح"
        })
    return jsonify({"success": False, "error": "تعذر حفظ البيانات"}), 500


@app.route("/api/admin/cookies/get-raw", methods=["POST"])
@require_admin
def admin_get_cookie_raw():

    data = request.get_json(silent=True) or {}
    cookie_id = data.get("id")
    pool = load_pool()
    target = next((c for c in pool if c.get("id") == cookie_id), None)
    if not target:
        return jsonify({"success": False, "error": "الكوكيز غير موجود"}), 404

    return jsonify({"success": True, "raw": target.get("raw", ""), "name": target.get("name", "")})


@app.route("/api/admin/cookies/test-all", methods=["POST"])
@require_admin
def admin_test_all_cookies():

    pool = load_pool()
    valid_count = 0
    expired_count = 0
    total = len(pool)

    for target in pool:
        try:
            cd = extract_cookie_dict(target.get("raw", ""))
            token, expires, err = fetch_nftoken_api(cd)
            if err or not token:
                target["last_status"] = "error"
                if "expired" in str(err).lower() or "no token found" in str(err).lower():
                    target["status"] = "expired"
                expired_count += 1
            else:
                target["last_status"] = "valid"
                target["status"] = "active"
                valid_count += 1
        except Exception:
            expired_count += 1

    save_pool(pool)
    return jsonify({
        "success": True,
        "total": total,
        "valid_count": valid_count,
        "expired_count": expired_count,
        "message": f"اكتمل الفحص: {valid_count} نشط / {expired_count} منتهي أو به خطأ"
    })


@app.route("/api/admin/cookies/bulk", methods=["POST"])
@require_admin
def admin_bulk_action():

    data = request.get_json(silent=True) or {}
    action = data.get("action")
    ids = set(data.get("ids", []))

    if not ids:
        return jsonify({"success": False, "error": "لم يتم تحديد أي حسابات"}), 400

    pool = load_pool()
    if action == "delete":
        pool = [c for c in pool if c.get("id") not in ids]
        save_pool(pool)
        return jsonify({"success": True, "message": f"تم حذف {len(ids)} حساب بنجاح"})
    elif action == "activate":
        count = 0
        for c in pool:
            if c.get("id") in ids:
                c["status"] = "active"
                count += 1
        save_pool(pool)
        return jsonify({"success": True, "message": f"تم تفعيل {count} حساب"})
    elif action == "deactivate":
        count = 0
        for c in pool:
            if c.get("id") in ids:
                c["status"] = "inactive"
                count += 1
        save_pool(pool)
        return jsonify({"success": True, "message": f"تم تعطيل {count} حساب"})

    return jsonify({"success": False, "error": "إجراء غير مدعوم"}), 400


@app.route("/api/admin/cookies/export", methods=["GET"])
@require_admin
def admin_export_cookies():

    pool = load_pool()
    return jsonify({
        "success": True,
        "exported_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total": len(pool),
        "pool": pool
    })


@app.route("/api/admin/system-info", methods=["GET"])
@require_admin
def admin_system_info():

    uptime_delta = datetime.now() - SERVER_START_TIME
    hours, remainder = divmod(int(uptime_delta.total_seconds()), 3600)
    minutes, seconds = divmod(remainder, 60)
    uptime_str = f"{hours}h {minutes}m {seconds}s"

    pool = load_pool()
    active_count = sum(1 for c in pool if c.get("status") == "active")
    device_limits = load_device_limits()

    return jsonify({
        "success": True,
        "uptime": uptime_str,
        "admin_username": get_admin_username(),
        "total_cookies": len(pool),
        "active_cookies": active_count,
        "today_active_devices": len(device_limits),
        "python_version": "3.13.5",
        "server_status": "Online",
        "started_at": SERVER_START_TIME.strftime("%Y-%m-%d %H:%M:%S")
    })


@app.route("/api/admin/reset-device-limits", methods=["POST"])
@require_admin
def admin_reset_device_limits():
    save_device_limits({})
    return jsonify({"success": True, "message": "تم تصفير حدود الأجهزة لليوم بنجاح (3 تفعيلات متاحة لكل جهاز الآن)"})


@app.route("/api/history", methods=["GET"])
@require_admin
def get_history():
    return jsonify({"success": True, "history": load_history()})


@app.route("/api/clear-history", methods=["POST"])
@require_admin
def clear_history():
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)
        return jsonify({"success": True, "message": "تم مسح السجل بنجاح"})
    except Exception:
        return jsonify({"success": False, "error": "فشل مسح السجل"}), 500


# Custom error handlers to prevent information leakage
@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify({"success": False, "error": "المورد غير موجود"}), 404
    return render_template("index.html"), 404


@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"success": False, "error": "طريقة الطلب غير مسموحة"}), 405


@app.errorhandler(413)
def request_too_large(e):
    return jsonify({"success": False, "error": "حجم الطلب كبير جداً"}), 413


@app.errorhandler(429)
def too_many_requests(e):
    return jsonify({"success": False, "error": "تم تجاوز الحد الأقصى للطلبات"}), 429


@app.errorhandler(500)
def internal_error(e):
    return jsonify({"success": False, "error": "خطأ داخلي في الخادم"}), 500


def get_local_network_ip():
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    lan_ip = get_local_network_ip()
    print("=" * 60)
    print("🚀 XNetflix Studio Web App is running:")
    print(f"   🏠 Local (هذا الجهاز):       http://127.0.0.1:{port}")
    print(f"   🌐 Network (الشبكة المحلية): http://{lan_ip}:{port}")
    print("=" * 60)
    app.run(host="0.0.0.0", port=port, debug=False)

