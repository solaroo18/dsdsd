// ==========================================================================
// XNetflix — Minimalist Auto-Activation Engine (Matching User Mockup)
// ==========================================================================

const translations = {
  ar: {
    tabComputer: "كمبيوتر",
    tabPhone: "هاتف",
    tabTv: "تلفاز",
    openNetflix: "فتح نتفلكس",
    connecting: "جاري الاتصال...",
    copyLoginLink: "نسخ رابط الدخول",
    copied: "✓ تم النسخ بنجاح!",
    helperComputer: 'اضغط "فتح نتفلكس" لتسجيل الدخول تلقائياً — بدون كلمة سر.',
    helperPhone: 'اضغط "فتح نتفلكس" للتفعيل على تطبيق أندرويد و iOS مباشرة.',
    helperTv: 'اضغط "فتح نتفلكس" لإدخال رمز شاشة التلفاز وتفعيله مباشرة.',
    btnNewLink: "رابط جديد",
    btnShowQr: "رمز QR",
    btnMyCookie: "الكوكيز الخاص بي",
    cookieHint: "ألصق كوكيز نتفلكس الخاص بك هنا لتوليد رابط الدخول واستخدامه فوراً.",
    btnGenerate: "توليد الرابط",
    cookieRequired: "يرجى لصق الكوكيز أولاً في المربع أعلاه.",
    cookieSuccess: "تم توليد رابط التفعيل من الكوكيز بنجاح!",
    qrScanHint: "امسح بكاميرا هاتفك للدخول الفوري إلى نتفلكس",
    generatingQr: "جاري تجهيز رمز QR...",
    adminLink: "لوحة الأدمن",
    retry: "إعادة المحاولة",
    noCookies: "عذراً، لا توجد حسابات متوفرة حالياً في النظام.",
    limitReached: "تم استنفاد الحد اليومي المسموح به لهذا الجهاز (3 تفعيلات يومياً).",
    serverError: "حدث خطأ في الاتصال بالخادم. يرجى المحاولة لاحقاً.",
    copyError: "تعذر النسخ التلقائي"
  },
  en: {
    tabComputer: "Computer",
    tabPhone: "Phone",
    tabTv: "TV",
    openNetflix: "Open Netflix",
    connecting: "Connecting...",
    copyLoginLink: "Copy login link",
    copied: "✓ Copied to clipboard!",
    helperComputer: 'Tap "Open Netflix" to sign in automatically — no password needed.',
    helperPhone: 'Tap "Open Netflix" to activate on Android or iOS app directly.',
    helperTv: 'Tap “Open Netflix” to enter your TV screen code directly.',
    btnNewLink: "New Link",
    btnShowQr: "QR Code",
    btnMyCookie: "My Cookie",
    cookieHint: "Paste your Netflix cookie below to generate a login link from your own account.",
    btnGenerate: "Generate Link",
    cookieRequired: "Please paste your Netflix cookie first.",
    cookieSuccess: "Login link generated from your cookie successfully!",
    qrScanHint: "Scan with phone camera to open on mobile",
    generatingQr: "Generating QR Code...",
    adminLink: "Admin",
    retry: "Retry",
    noCookies: "No active accounts in pool currently. Please notify administrator.",
    limitReached: "Daily limit reached for this device (3 activations/day). Resets tomorrow!",
    serverError: "Server connection error. Please try again.",
    copyError: "Failed to copy link"
  }
};

// Application State
const state = {
  currentDevice: "tv", // default matches user screenshot
  currentLang: localStorage.getItem("nftoken_lang") || "en",
  urls: {
    computer: "",
    phone: "",
    tv: ""
  },
  qrs: {
    computer: "",
    phone: "",
    tv: ""
  },
  token: null,
  loading: false,
  qrOpen: false,
  cookieDrawerOpen: false
};

// DOM Elements
let elTabComputer, elTabPhone, elTabTv;
let elBtnOpenNetflix, elMainBtnSpinner, elBtnPlayIcon, elBtnOpenLabel;
let elBtnCopyLogin, elBtnCopyLabel, elBtnCopyIcon;
let elSimpleHelperNote;
let elBtnRefreshLink, elBtnToggleQr, elQrDrawer, elQrDrawerImg;
let elBtnToggleMyCookie, elCookieDrawer, elCookieTextarea, elBtnGenerateCookie, elCookieBtnSpinner, elCookieBtnIcon, elCookieBtnLabel;
let elSimpleAlertBox, elSimpleAlertMsg, elBtnAlertRetry;
let elBtnToggleLang, elLangLabel;

// Initialization
document.addEventListener("DOMContentLoaded", () => {
  cacheElements();
  setupLanguage();
  setupDeviceTabs();
  setupActions();
  autoGenerateToken();
});

function cacheElements() {
  elTabComputer = document.getElementById("tabComputer");
  elTabPhone = document.getElementById("tabPhone");
  elTabTv = document.getElementById("tabTv");

  elBtnOpenNetflix = document.getElementById("btnOpenNetflix");
  elMainBtnSpinner = document.getElementById("mainBtnSpinner");
  elBtnPlayIcon = document.getElementById("btnPlayIcon");
  elBtnOpenLabel = document.getElementById("btnOpenLabel");

  elBtnCopyLogin = document.getElementById("btnCopyLogin");
  elBtnCopyLabel = document.getElementById("btnCopyLabel");
  elBtnCopyIcon = document.getElementById("btnCopyIcon");

  elSimpleHelperNote = document.getElementById("simpleHelperNote");

  elBtnRefreshLink = document.getElementById("btnRefreshLink");
  elBtnToggleQr = document.getElementById("btnToggleQr");
  elQrDrawer = document.getElementById("qrDrawer");
  elQrDrawerImg = document.getElementById("qrDrawerImg");

  elBtnToggleMyCookie = document.getElementById("btnToggleMyCookie");
  elCookieDrawer = document.getElementById("cookieDrawer");
  elCookieTextarea = document.getElementById("cookieTextarea");
  elBtnGenerateCookie = document.getElementById("btnGenerateCookie");
  elCookieBtnSpinner = document.getElementById("cookieBtnSpinner");
  elCookieBtnIcon = document.getElementById("cookieBtnIcon");
  elCookieBtnLabel = document.getElementById("cookieBtnLabel");

  elSimpleAlertBox = document.getElementById("simpleAlertBox");
  elSimpleAlertMsg = document.getElementById("simpleAlertMsg");
  elBtnAlertRetry = document.getElementById("btnAlertRetry");

  elBtnToggleLang = document.getElementById("btnToggleLang");
  elLangLabel = document.getElementById("langLabel");
}

function t(key) {
  const dict = translations[state.currentLang] || translations.en;
  return dict[key] || key;
}

// Language Handling
function setupLanguage() {
  applyLanguage(state.currentLang);

  if (elBtnToggleLang) {
    elBtnToggleLang.addEventListener("click", () => {
      const nextLang = state.currentLang === "en" ? "ar" : "en";
      applyLanguage(nextLang);
    });
  }
}

function applyLanguage(lang) {
  state.currentLang = lang;
  localStorage.setItem("nftoken_lang", lang);

  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";

  if (elLangLabel) {
    elLangLabel.textContent = lang === "ar" ? "English" : "العربية";
  }

  // Update all [data-i18n] elements
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (key && translations[lang][key]) {
      el.textContent = translations[lang][key];
    }
  });

  updateHelperNote();
  updateOpenButtonLabel();
}

// Device Identification — localStorage-based (Layer 4)
function getOrCreateDeviceId() {
  let devId = localStorage.getItem("nftoken_device_id");
  if (!devId || devId.length < 16) {
    devId = "dev_" + "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      const v = c === "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
    localStorage.setItem("nftoken_device_id", devId);
  }
  return devId;
}

// Canvas / Hardware Fingerprint — consistent across incognito & browser sessions (Layer 2)
function generateCanvasFingerprint() {
  try {
    const canvas = document.createElement("canvas");
    canvas.width = 280;
    canvas.height = 60;
    const ctx = canvas.getContext("2d");
    if (!ctx) return "";

    // Draw text with specific font rendering
    ctx.textBaseline = "alphabetic";
    ctx.font = "14px 'Arial'";
    ctx.fillStyle = "#f60";
    ctx.fillRect(30, 1, 120, 28);
    ctx.fillStyle = "#069";
    ctx.fillText("Cwm fjord veg", 2, 15);
    ctx.fillStyle = "rgba(102,204,0,0.7)";
    ctx.fillText("quiz, ½ pint.", 4, 45);

    // Draw a unique arc
    ctx.beginPath();
    ctx.arc(50, 50, 50, 0, Math.PI * 2, true);
    ctx.closePath();
    ctx.fill();

    // Get canvas data
    const dataUrl = canvas.toDataURL();

    // Combine with hardware signals for uniqueness
    const signals = [
      dataUrl,
      screen.width + "x" + screen.height,
      screen.colorDepth,
      Intl.DateTimeFormat().resolvedOptions().timeZone || "",
      navigator.hardwareConcurrency || 0,
      navigator.maxTouchPoints || 0,
      navigator.platform || ""
    ];

    // Try adding WebGL renderer info
    try {
      const gl = document.createElement("canvas").getContext("webgl");
      if (gl) {
        const dbg = gl.getExtension("WEBGL_debug_renderer_info");
        if (dbg) {
          signals.push(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || "");
        }
      }
    } catch (e) { /* silent */ }

    // Hash using simple djb2
    const raw = signals.join("|");
    let hash = 5381;
    for (let i = 0; i < raw.length; i++) {
      hash = ((hash << 5) + hash + raw.charCodeAt(i)) >>> 0;
    }
    return hash.toString(36) + "_" + simpleHash(raw);
  } catch (e) {
    return "";
  }
}

function simpleHash(str) {
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < str.length; i++) {
    const ch = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}

// Cache the fingerprint so it's consistent within the session
let _cachedCanvasFP = null;
function getCanvasFingerprint() {
  if (!_cachedCanvasFP) {
    _cachedCanvasFP = generateCanvasFingerprint();
  }
  return _cachedCanvasFP;
}

// Automatic Token Generation
async function autoGenerateToken(isManualRefresh = false) {
  if (state.loading) return;
  state.loading = true;

  hideAlert();
  setLoadingState(true);

  try {
    const devId = getOrCreateDeviceId();
    const canvasFP = getCanvasFingerprint();
    const response = await fetch("/api/generate-from-pool", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Device-Id": devId,
        "X-Canvas-FP": canvasFP
      }
    });

    const data = await response.json();

    if (data.success) {
      state.token = data.token;
      state.urls.computer = data.browse_url || data.login_url;
      state.urls.phone = data.unsupported_url || data.login_url;
      state.urls.tv = data.tv_activation_url || data.login_url;

      state.qrs.computer = data.login_qr || "";
      state.qrs.phone = data.unsupported_qr || data.login_qr || "";
      state.qrs.tv = data.tv_qr || data.login_qr || "";

      setReadyState();

      if (isManualRefresh) {
        showToast(state.currentLang === "ar" ? "تم توليد رابط جديد بنجاح" : "New link generated!", "success");
      }
    } else {
      handleGenerationError(data, response.status);
    }
  } catch (err) {
    console.error("Auto generation failed:", err);
    showAlert(t("serverError"));
    setDisabledState();
  } finally {
    state.loading = false;
    setLoadingState(false);
  }
}

function handleGenerationError(data, status) {
  setDisabledState();
  if (status === 429 || data.limit_reached) {
    showAlert(t("limitReached"));
  } else if (data.details && data.details.includes("empty")) {
    showAlert(t("noCookies"));
  } else {
    showAlert(data.error || t("serverError"));
  }
}

function setLoadingState(isLoading) {
  if (isLoading) {
    if (elBtnOpenNetflix) {
      elBtnOpenNetflix.classList.add("loading", "disabled");
      if (elBtnOpenLabel) elBtnOpenLabel.textContent = t("connecting");
    }
    if (elBtnCopyLogin) elBtnCopyLogin.classList.add("disabled");
  } else {
    if (elBtnOpenNetflix) {
      elBtnOpenNetflix.classList.remove("loading");
    }
  }
}

function setReadyState() {
  const currentUrl = state.urls[state.currentDevice] || "#";

  if (elBtnOpenNetflix) {
    elBtnOpenNetflix.classList.remove("disabled");
    elBtnOpenNetflix.href = currentUrl;
    updateOpenButtonLabel();
  }

  if (elBtnCopyLogin) {
    elBtnCopyLogin.classList.remove("disabled");
  }

  updateHelperNote();
  updateQrDrawerImage();
}

function setDisabledState() {
  if (elBtnOpenNetflix) {
    elBtnOpenNetflix.classList.add("disabled");
    elBtnOpenNetflix.removeAttribute("href");
    updateOpenButtonLabel();
  }
  if (elBtnCopyLogin) {
    elBtnCopyLogin.classList.add("disabled");
  }
}

function updateOpenButtonLabel() {
  if (!elBtnOpenLabel) return;
  if (state.loading) {
    elBtnOpenLabel.textContent = t("connecting");
  } else {
    elBtnOpenLabel.textContent = t("openNetflix");
  }
}

function updateHelperNote() {
  if (!elSimpleHelperNote) return;
  let key = "helperTv";
  if (state.currentDevice === "computer") key = "helperComputer";
  else if (state.currentDevice === "phone") key = "helperPhone";

  elSimpleHelperNote.textContent = t(key);
}

function updateQrDrawerImage() {
  if (!elQrDrawerImg) return;
  const qr = state.qrs[state.currentDevice];
  const loadingBox = document.getElementById("qrLoadingBox");
  if (qr) {
    elQrDrawerImg.src = qr;
    elQrDrawerImg.classList.remove("hidden");
    if (loadingBox) loadingBox.classList.add("hidden");
  } else {
    elQrDrawerImg.classList.add("hidden");
    if (loadingBox) loadingBox.classList.remove("hidden");
  }
}

// Device Tabs Switching
function setupDeviceTabs() {
  const tabs = [
    { el: elTabComputer, device: "computer" },
    { el: elTabPhone, device: "phone" },
    { el: elTabTv, device: "tv" }
  ];

  tabs.forEach(({ el, device }) => {
    if (!el) return;
    el.addEventListener("click", () => {
      if (state.currentDevice === device) return;
      selectDevice(device);
    });
  });
}

function selectDevice(device) {
  state.currentDevice = device;

  [elTabComputer, elTabPhone, elTabTv].forEach((tab) => {
    if (tab) tab.classList.remove("active");
  });

  if (device === "computer" && elTabComputer) elTabComputer.classList.add("active");
  if (device === "phone" && elTabPhone) elTabPhone.classList.add("active");
  if (device === "tv" && elTabTv) elTabTv.classList.add("active");

  const url = state.urls[device];
  if (url && elBtnOpenNetflix && !state.loading) {
    elBtnOpenNetflix.href = url;
  }

  updateHelperNote();
  updateQrDrawerImage();
}

// Actions (Open, Copy, Refresh, QR)
function setupActions() {
  // Copy button
  if (elBtnCopyLogin) {
    elBtnCopyLogin.addEventListener("click", async () => {
      const urlToCopy = state.urls[state.currentDevice];
      if (!urlToCopy) return;

      try {
        await navigator.clipboard.writeText(urlToCopy);
        triggerCopySuccess();
      } catch (err) {
        // Fallback for older browsers
        const textarea = document.createElement("textarea");
        textarea.value = urlToCopy;
        textarea.style.position = "fixed";
        textarea.style.opacity = "0";
        document.body.appendChild(textarea);
        textarea.select();
        try {
          document.execCommand("copy");
          triggerCopySuccess();
        } catch (e) {
          showToast(t("copyError"), "error");
        }
        document.body.removeChild(textarea);
      }
    });
  }

  // Refresh / New Link
  if (elBtnRefreshLink) {
    elBtnRefreshLink.addEventListener("click", () => {
      autoGenerateToken(true);
    });
  }

  // Toggle QR Code Drawer
  if (elBtnToggleQr) {
    elBtnToggleQr.addEventListener("click", () => {
      state.qrOpen = !state.qrOpen;
      if (elQrDrawer) {
        elQrDrawer.classList.toggle("hidden", !state.qrOpen);
        if (state.qrOpen) {
          updateQrDrawerImage();
          // Close cookie drawer if open
          if (state.cookieDrawerOpen) {
            state.cookieDrawerOpen = false;
            if (elCookieDrawer) elCookieDrawer.classList.add("hidden");
          }
        }
      }
    });
  }

  // Toggle My Cookie Drawer
  if (elBtnToggleMyCookie) {
    elBtnToggleMyCookie.addEventListener("click", () => {
      state.cookieDrawerOpen = !state.cookieDrawerOpen;
      if (elCookieDrawer) {
        elCookieDrawer.classList.toggle("hidden", !state.cookieDrawerOpen);
        if (state.cookieDrawerOpen) {
          // Close QR drawer if open
          if (state.qrOpen) {
            state.qrOpen = false;
            if (elQrDrawer) elQrDrawer.classList.add("hidden");
          }
          if (elCookieTextarea) {
            setTimeout(() => elCookieTextarea.focus(), 100);
          }
        }
      }
    });
  }

  // Generate from custom cookie button
  if (elBtnGenerateCookie) {
    elBtnGenerateCookie.addEventListener("click", () => {
      generateCustomTokenFromCookie();
    });
  }

  // Retry Alert Button
  if (elBtnAlertRetry) {
    elBtnAlertRetry.addEventListener("click", () => {
      autoGenerateToken(true);
    });
  }
}

// Generate Token from user's custom cookie
async function generateCustomTokenFromCookie() {
  if (!elCookieTextarea) return;
  const rawCookie = elCookieTextarea.value.trim();
  if (!rawCookie) {
    showToast(t("cookieRequired"), "error");
    elCookieTextarea.focus();
    return;
  }

  if (state.loading) return;
  state.loading = true;

  if (elBtnGenerateCookie) elBtnGenerateCookie.disabled = true;
  if (elCookieBtnSpinner) elCookieBtnSpinner.classList.remove("hidden");
  if (elCookieBtnIcon) elCookieBtnIcon.classList.add("hidden");

  hideAlert();
  setLoadingState(true);

  try {
    const devId = getOrCreateDeviceId();
    const canvasFP = getCanvasFingerprint();
    const response = await fetch("/api/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Device-Id": devId,
        "X-Canvas-FP": canvasFP
      },
      body: JSON.stringify({ cookie: rawCookie })
    });

    const data = await response.json();

    if (data.success) {
      state.token = data.token;
      state.urls.computer = data.browse_url || data.login_url;
      state.urls.phone = data.unsupported_url || data.login_url;
      state.urls.tv = data.tv_activation_url || data.login_url;

      state.qrs.computer = data.login_qr || "";
      state.qrs.phone = data.unsupported_qr || data.login_qr || "";
      state.qrs.tv = data.tv_qr || data.login_qr || "";

      setReadyState();
      showToast(t("cookieSuccess"), "success");

      // Auto close the cookie drawer on success
      state.cookieDrawerOpen = false;
      if (elCookieDrawer) elCookieDrawer.classList.add("hidden");
    } else {
      handleGenerationError(data, response.status);
    }
  } catch (err) {
    console.error("Custom cookie generation failed:", err);
    showAlert(t("serverError"));
    setDisabledState();
  } finally {
    state.loading = false;
    setLoadingState(false);
    if (elBtnGenerateCookie) elBtnGenerateCookie.disabled = false;
    if (elCookieBtnSpinner) elCookieBtnSpinner.classList.add("hidden");
    if (elCookieBtnIcon) elCookieBtnIcon.classList.remove("hidden");
  }
}

function triggerCopySuccess() {
  if (!elBtnCopyLogin || !elBtnCopyLabel) return;
  elBtnCopyLogin.classList.add("copied");
  const originalText = t("copyLoginLink");
  elBtnCopyLabel.textContent = t("copied");

  setTimeout(() => {
    elBtnCopyLogin.classList.remove("copied");
    elBtnCopyLabel.textContent = originalText;
  }, 2200);
}

// Alert Message Helper
function showAlert(message) {
  if (!elSimpleAlertBox || !elSimpleAlertMsg) return;
  elSimpleAlertMsg.textContent = message;
  elSimpleAlertBox.classList.remove("hidden");
}

function hideAlert() {
  if (!elSimpleAlertBox) return;
  elSimpleAlertBox.classList.add("hidden");
}

// Toast Notifications
function showToast(message, type = "info") {
  const container = document.getElementById("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add("fade-out");
    setTimeout(() => {
      if (toast.parentElement) toast.parentElement.removeChild(toast);
    }, 300);
  }, 2800);
}
